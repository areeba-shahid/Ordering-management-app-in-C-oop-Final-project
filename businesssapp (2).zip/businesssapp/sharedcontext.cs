﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace businesssapp
{
    public static class SharedContext
    {
        private static string _username;
        private static int _userid;
        private static int itemid;
        private static List<ListViewItem> selectedElectronics = new List<ListViewItem>();
     private  static List<ListViewItem> selectedCosmetics = new List<ListViewItem>();
    private  static  List<ListViewItem> selectedHomeDecor = new List<ListViewItem>();


       
        public static string Username
        {
            get { return _username; }
            set { _username = value; }
        }
        public static int Userid
        {
            get { return _userid; }
            set { _userid = value; }
        }
        public static int _itemid
        {
            get { return itemid; }
            set { itemid = value; }
        }

        public static void AddBoughtelectronics(ListViewItem item)
        {
            selectedElectronics.Add(item);
            

        }
        public static void AddBoughtcosmetics(ListViewItem item)
        {
            selectedCosmetics.Add(item);
          
        }
        public static void AddBoughthomedecor(ListViewItem item)
        {
            selectedHomeDecor.Add(item);
            
        }
        

        public static void ClearSelectedItems()
        {
            selectedElectronics.Clear();
            selectedCosmetics.Clear();
            selectedHomeDecor.Clear();
        }
       public static List<ListViewItem> getelectronics()
        {
            return selectedElectronics;
        }
        public static List<ListViewItem> getcosmetics()
        {
            return selectedCosmetics;
        }
        public static List<ListViewItem> gethomedecor()
        {
            return selectedHomeDecor;
        }

        

       

    }
}
