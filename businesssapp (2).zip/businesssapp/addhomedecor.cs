﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace businesssapp
{
    public partial class addhomedecor : Form
    {
        public addhomedecor()
        {
            InitializeComponent();
          
        }
        bool buttonclick = false;
        private void setname()
        {
            label1.Text = SharedContext.Username;
        }
        private List<homeDecor> newhomedecor = new List<homeDecor>();
        private void exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }

        private void add_Click(object sender, EventArgs e)
        {
            List<homeDecor> topasslist = accessall();
            homedecorDB home = new homedecorDB(objecthandler.conn);
            home.storeindb(topasslist);
            buttonclick = true;
            bool textboxcondition = AreAllTextBoxesFilled();
            if (buttonclick && textboxcondition)
            {


            }
            else
            {
                MessageBox.Show("Fill out all information Correctly");
            }
        }

        private void addhomedecor_Load(object sender, EventArgs e)
        {

        }

        private List<homeDecor> accessall()
        {
            string name = nametxt.Text; ;
            string type = typetxt.Text;
            string company = companytxt.Text;
            float cost = Convert.ToSingle(costtxt.Text);
            string[] color = coloroptxt.Text.Split(',');
            int availibility = Convert.ToInt32(availtxt.Text);
            DateTime dateofmanufacture = Convert.ToDateTime(domtxt.Text);
            DateTime dateofexpire = Convert.ToDateTime(doetxt.Text);
            float warranty = Convert.ToSingle(warrantytxt.Text);
            string[] dimensions = dimensiontxt.Text.Split(',');
            float quantity = Convert.ToSingle(quantitytxt.Text);
            string material = materialtxt.Text;

         


            homeDecor elec = new homeDecor(name, type, company, color, cost, availibility, dateofmanufacture, dateofexpire, warranty, dimensions, quantity, material);

            newhomedecor.Add(elec);
            return newhomedecor;
        }

        private bool AreAllTextBoxesFilled()
        {
            foreach (Control control in Controls) 
            {
                if (control is System.Windows.Forms.TextBox textBox) 
                {
                    if (string.IsNullOrEmpty(textBox.Text)) 
                    {
                        return false; 
                    }
                }
            }
            return true; // Return true if all TextBoxes are filled
        }
    }
}
