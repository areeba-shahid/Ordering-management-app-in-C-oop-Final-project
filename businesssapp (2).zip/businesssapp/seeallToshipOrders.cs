﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class seeallToshipOrders : Form
    {
        public seeallToshipOrders()
        {
            InitializeComponent();
            InitializeToShipList();
        }
        private void InitializeToShipList()
        {
            List<paymentBL> paylist = objecthandler.getpayment().getalltoshipitem();

            foreach (paymentBL homedecitem in paylist)
            {
                ListViewItem item = new ListViewItem(homedecitem.OrderId.ToString());
                item.SubItems.Add(homedecitem.CustomerName); // Format price as currency


                item.SubItems.Add(homedecitem.CustomerId.ToString());
                item.SubItems.Add(string.Join(",", homedecitem.Items));
                item.SubItems.Add(homedecitem.Price.ToString());
                item.SubItems.Add(homedecitem.PaymentMethod);
               

                listView1.Items.Add(item);


            }
            paylist.Clear();
        }
        private void seeallToshipOrders_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu cos = new adminmenu();
            cos.ShowDialog();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
