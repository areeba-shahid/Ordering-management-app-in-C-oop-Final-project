﻿namespace businesssapp
{
    partial class editcosmetics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.doetxt = new System.Windows.Forms.TextBox();
            this.doe = new System.Windows.Forms.Label();
            this.domtxt = new System.Windows.Forms.TextBox();
            this.dom = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Button();
            this.typeofelectronic = new System.Windows.Forms.Label();
            this.quantitytxt = new System.Windows.Forms.TextBox();
            this.dimensiontxt = new System.Windows.Forms.TextBox();
            this.dimensions = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.Label();
            this.companytxt = new System.Windows.Forms.TextBox();
            this.warrantytxt = new System.Windows.Forms.TextBox();
            this.costtxt = new System.Windows.Forms.TextBox();
            this.coloroptxt = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.warranty = new System.Windows.Forms.Label();
            this.company = new System.Windows.Forms.Label();
            this.color = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.skintypetxt = new System.Windows.Forms.TextBox();
            this.shadetxt = new System.Windows.Forms.TextBox();
            this.packagetxt = new System.Windows.Forms.TextBox();
            this.shade = new System.Windows.Forms.Label();
            this.package = new System.Windows.Forms.Label();
            this.skintype = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // doetxt
            // 
            this.doetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.doetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doetxt.Location = new System.Drawing.Point(283, 387);
            this.doetxt.Name = "doetxt";
            this.doetxt.Size = new System.Drawing.Size(154, 20);
            this.doetxt.TabIndex = 210;
            // 
            // doe
            // 
            this.doe.AutoSize = true;
            this.doe.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.doe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doe.Location = new System.Drawing.Point(58, 385);
            this.doe.Name = "doe";
            this.doe.Size = new System.Drawing.Size(129, 20);
            this.doe.TabIndex = 209;
            this.doe.Text = "Add Date Expire:";
            // 
            // domtxt
            // 
            this.domtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.domtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.domtxt.Location = new System.Drawing.Point(283, 352);
            this.domtxt.Name = "domtxt";
            this.domtxt.Size = new System.Drawing.Size(154, 20);
            this.domtxt.TabIndex = 208;
            // 
            // dom
            // 
            this.dom.AutoSize = true;
            this.dom.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dom.Location = new System.Drawing.Point(58, 350);
            this.dom.Name = "dom";
            this.dom.Size = new System.Drawing.Size(191, 20);
            this.dom.TabIndex = 207;
            this.dom.Text = "Add Date of manufactire :";
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.add.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.add.Location = new System.Drawing.Point(609, 417);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(157, 57);
            this.add.TabIndex = 206;
            this.add.Text = "Save Updates";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // typeofelectronic
            // 
            this.typeofelectronic.AutoSize = true;
            this.typeofelectronic.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.typeofelectronic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeofelectronic.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.typeofelectronic.Location = new System.Drawing.Point(618, 253);
            this.typeofelectronic.Name = "typeofelectronic";
            this.typeofelectronic.Size = new System.Drawing.Size(0, 20);
            this.typeofelectronic.TabIndex = 200;
            // 
            // quantitytxt
            // 
            this.quantitytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quantitytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.quantitytxt.Location = new System.Drawing.Point(834, 288);
            this.quantitytxt.Name = "quantitytxt";
            this.quantitytxt.Size = new System.Drawing.Size(154, 20);
            this.quantitytxt.TabIndex = 199;
            // 
            // dimensiontxt
            // 
            this.dimensiontxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dimensiontxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dimensiontxt.Location = new System.Drawing.Point(834, 251);
            this.dimensiontxt.Name = "dimensiontxt";
            this.dimensiontxt.Size = new System.Drawing.Size(154, 20);
            this.dimensiontxt.TabIndex = 198;
            // 
            // dimensions
            // 
            this.dimensions.AutoSize = true;
            this.dimensions.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dimensions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dimensions.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dimensions.Location = new System.Drawing.Point(593, 251);
            this.dimensions.Name = "dimensions";
            this.dimensions.Size = new System.Drawing.Size(128, 20);
            this.dimensions.TabIndex = 197;
            this.dimensions.Text = "Edit Dimensions:";
            // 
            // quantity
            // 
            this.quantity.AutoSize = true;
            this.quantity.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantity.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.quantity.Location = new System.Drawing.Point(593, 286);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(100, 20);
            this.quantity.TabIndex = 196;
            this.quantity.Text = "Edit Quantity";
            // 
            // companytxt
            // 
            this.companytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.companytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.companytxt.Location = new System.Drawing.Point(283, 253);
            this.companytxt.Name = "companytxt";
            this.companytxt.Size = new System.Drawing.Size(154, 20);
            this.companytxt.TabIndex = 195;
            // 
            // warrantytxt
            // 
            this.warrantytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.warrantytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.warrantytxt.Location = new System.Drawing.Point(834, 213);
            this.warrantytxt.Name = "warrantytxt";
            this.warrantytxt.Size = new System.Drawing.Size(154, 20);
            this.warrantytxt.TabIndex = 194;
            // 
            // costtxt
            // 
            this.costtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.costtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.costtxt.Location = new System.Drawing.Point(283, 319);
            this.costtxt.Name = "costtxt";
            this.costtxt.Size = new System.Drawing.Size(154, 20);
            this.costtxt.TabIndex = 193;
            // 
            // coloroptxt
            // 
            this.coloroptxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.coloroptxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.coloroptxt.Location = new System.Drawing.Point(283, 286);
            this.coloroptxt.Name = "coloroptxt";
            this.coloroptxt.Size = new System.Drawing.Size(154, 20);
            this.coloroptxt.TabIndex = 192;
            // 
            // nametxt
            // 
            this.nametxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.nametxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.nametxt.Location = new System.Drawing.Point(283, 213);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(154, 20);
            this.nametxt.TabIndex = 191;
            // 
            // warranty
            // 
            this.warranty.AutoSize = true;
            this.warranty.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.warranty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warranty.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.warranty.Location = new System.Drawing.Point(593, 213);
            this.warranty.Name = "warranty";
            this.warranty.Size = new System.Drawing.Size(173, 20);
            this.warranty.TabIndex = 190;
            this.warranty.Text = "Edit Warranty (in years)";
            // 
            // company
            // 
            this.company.AutoSize = true;
            this.company.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.company.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.company.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.company.Location = new System.Drawing.Point(58, 253);
            this.company.Name = "company";
            this.company.Size = new System.Drawing.Size(116, 20);
            this.company.TabIndex = 189;
            this.company.Text = "Edit Company :";
            // 
            // color
            // 
            this.color.AutoSize = true;
            this.color.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.color.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.color.Location = new System.Drawing.Point(58, 286);
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(143, 20);
            this.color.TabIndex = 188;
            this.color.Text = "edit Color Options :";
            // 
            // Cost
            // 
            this.Cost.AutoSize = true;
            this.Cost.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cost.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Cost.Location = new System.Drawing.Point(58, 317);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(82, 20);
            this.Cost.TabIndex = 187;
            this.Cost.Text = "Edit Cost :";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.name.Location = new System.Drawing.Point(58, 222);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(89, 20);
            this.name.TabIndex = 186;
            this.name.Text = "Edit name :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(62, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(907, 164);
            this.dataGridView1.TabIndex = 185;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label5.Location = new System.Drawing.Point(394, -2);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(277, 45);
            this.label5.TabIndex = 184;
            this.label5.Text = "Edit Cosmetics";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(44, 417);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(157, 57);
            this.button1.TabIndex = 211;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // skintypetxt
            // 
            this.skintypetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.skintypetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.skintypetxt.Location = new System.Drawing.Point(834, 321);
            this.skintypetxt.Name = "skintypetxt";
            this.skintypetxt.Size = new System.Drawing.Size(154, 20);
            this.skintypetxt.TabIndex = 217;
            // 
            // shadetxt
            // 
            this.shadetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.shadetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.shadetxt.Location = new System.Drawing.Point(834, 354);
            this.shadetxt.Name = "shadetxt";
            this.shadetxt.Size = new System.Drawing.Size(154, 20);
            this.shadetxt.TabIndex = 216;
            // 
            // packagetxt
            // 
            this.packagetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.packagetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.packagetxt.Location = new System.Drawing.Point(834, 389);
            this.packagetxt.Name = "packagetxt";
            this.packagetxt.Size = new System.Drawing.Size(154, 20);
            this.packagetxt.TabIndex = 215;
            // 
            // shade
            // 
            this.shade.AutoSize = true;
            this.shade.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.shade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shade.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.shade.Location = new System.Drawing.Point(596, 352);
            this.shade.Name = "shade";
            this.shade.Size = new System.Drawing.Size(97, 20);
            this.shade.TabIndex = 214;
            this.shade.Text = "Add  Shade:";
            // 
            // package
            // 
            this.package.AutoSize = true;
            this.package.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.package.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.package.Location = new System.Drawing.Point(596, 387);
            this.package.Name = "package";
            this.package.Size = new System.Drawing.Size(162, 20);
            this.package.TabIndex = 213;
            this.package.Text = "Add Packaging Type :";
            // 
            // skintype
            // 
            this.skintype.AutoSize = true;
            this.skintype.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.skintype.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skintype.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.skintype.Location = new System.Drawing.Point(593, 319);
            this.skintype.Name = "skintype";
            this.skintype.Size = new System.Drawing.Size(112, 20);
            this.skintype.TabIndex = 212;
            this.skintype.Text = "Add skintype  :";
            // 
            // editcosmetics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::businesssapp.Properties.Resources.cossss;
            this.ClientSize = new System.Drawing.Size(1048, 483);
            this.Controls.Add(this.skintypetxt);
            this.Controls.Add(this.shadetxt);
            this.Controls.Add(this.packagetxt);
            this.Controls.Add(this.shade);
            this.Controls.Add(this.package);
            this.Controls.Add(this.skintype);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.doetxt);
            this.Controls.Add(this.doe);
            this.Controls.Add(this.domtxt);
            this.Controls.Add(this.dom);
            this.Controls.Add(this.add);
            this.Controls.Add(this.typeofelectronic);
            this.Controls.Add(this.quantitytxt);
            this.Controls.Add(this.dimensiontxt);
            this.Controls.Add(this.dimensions);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.companytxt);
            this.Controls.Add(this.warrantytxt);
            this.Controls.Add(this.costtxt);
            this.Controls.Add(this.coloroptxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.warranty);
            this.Controls.Add(this.company);
            this.Controls.Add(this.color);
            this.Controls.Add(this.Cost);
            this.Controls.Add(this.name);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label5);
            this.Name = "editcosmetics";
            this.Text = "editcosmetics";
            this.Load += new System.EventHandler(this.editcosmetics_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox doetxt;
        private System.Windows.Forms.Label doe;
        private System.Windows.Forms.TextBox domtxt;
        private System.Windows.Forms.Label dom;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Label typeofelectronic;
        private System.Windows.Forms.TextBox quantitytxt;
        private System.Windows.Forms.TextBox dimensiontxt;
        private System.Windows.Forms.Label dimensions;
        private System.Windows.Forms.Label quantity;
        private System.Windows.Forms.TextBox companytxt;
        private System.Windows.Forms.TextBox warrantytxt;
        private System.Windows.Forms.TextBox costtxt;
        private System.Windows.Forms.TextBox coloroptxt;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label warranty;
        private System.Windows.Forms.Label company;
        private System.Windows.Forms.Label color;
        private System.Windows.Forms.Label Cost;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox skintypetxt;
        private System.Windows.Forms.TextBox shadetxt;
        private System.Windows.Forms.TextBox packagetxt;
        private System.Windows.Forms.Label shade;
        private System.Windows.Forms.Label package;
        private System.Windows.Forms.Label skintype;
    }
}