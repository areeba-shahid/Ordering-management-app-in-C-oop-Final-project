﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{

    public partial class addcosmetic : Form
    {
        public addcosmetic()
        {
            InitializeComponent();
           
        }
        bool buttonclick = false;
        private void setname()
        {
            label1.Text = SharedContext.Username;
        }
        private List<cosmetics> newcosmetic = new List<cosmetics>();

        private void label2_Click(object sender, EventArgs e)
        {

        }
      
        private List<cosmetics> accessall()
        {
            string name = nametxt.Text; ;
            string type = typetxt.Text;
            string company = companytxt.Text;
            float cost = Convert.ToSingle(costtxt.Text);
            string[] color = coloroptxt.Text.Split(',');
            int availibility = Convert.ToInt32(availtxt.Text);
            DateTime dateofmanufacture = Convert.ToDateTime(domtxt.Text);
            DateTime dateofexpire = Convert.ToDateTime(doetxt.Text);
            float warranty = Convert.ToSingle(warrantytxt.Text);
            string[] dimensions = dimensiontxt.Text.Split(',');
            float quantity = Convert.ToSingle(quantitytxt.Text);
            string skintype = skintypetxt.Text;

            string shade = shadetxt.Text;

            string packaging = packagetxt.Text;
          
            
            cosmetics cos = new cosmetics(name, type, company, color, cost, availibility, dateofmanufacture, dateofexpire, warranty, dimensions, quantity, skintype, shade, packaging);

            newcosmetic.Add(cos);
            return newcosmetic;
        }
        private void exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }
        private bool AreAllTextBoxesFilled()
        {
            foreach (Control control in Controls) 
            {
                if (control is System.Windows.Forms.TextBox textBox) 
                {
                    if (string.IsNullOrEmpty(textBox.Text)) 
                    {
                        return false; 
                    }
                }
            }
            return true; 
        }

        private void addcosmetic_Load(object sender, EventArgs e)
        {

        }

       
      

        private void add_Click(object sender, EventArgs e)
        {
            List<cosmetics> topasslist=  accessall();
            cosmeticDB cosm = new cosmeticDB(objecthandler.conn);
            cosm.storeindb(topasslist);
           buttonclick = true;
            bool textboxcondition = AreAllTextBoxesFilled();
            if (buttonclick && textboxcondition)
            {
                

            }
            else
            {
                MessageBox.Show("Fill out all information Correctly");
            }
          
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
