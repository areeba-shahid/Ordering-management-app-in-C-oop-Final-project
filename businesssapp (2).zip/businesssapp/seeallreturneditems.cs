﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class seeallreturneditems : Form
    {
        public seeallreturneditems()
        {
            InitializeComponent();
            Initilaizeallreturneditems();
        }

        private void seeallreturneditems_Load(object sender, EventArgs e)
        {
            List<ReturnItem> returnedlist = objecthandler.getreturn().retrieveall();

            foreach (ReturnItem homedecitem in returnedlist)
            {
                ListViewItem item = new ListViewItem(homedecitem.ItemId.ToString());
                item.SubItems.Add(homedecitem.customerid.ToString());


                item.SubItems.Add(homedecitem.customername.ToString());
                item.SubItems.Add(homedecitem.getname().ToString());
           
                item.SubItems.Add(homedecitem.Color.ToString());
                item.SubItems.Add(homedecitem.getcompany());
                item.SubItems.Add(homedecitem.getcost().ToString());
                item.SubItems.Add(homedecitem.getType());


                listView1.Items.Add(item);


            }
            returnedlist.Clear();
        }
        private void Initilaizeallreturneditems()
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu cos = new adminmenu();
            cos.ShowDialog();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
