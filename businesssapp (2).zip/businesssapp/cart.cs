﻿using businessapplibrary;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace businesssapp
{
    public partial class cart : Form
    {

        public cart()
        {
            InitializeComponent();
            AddItemsToListView();
            SetLabelText();
        }
        public ListView ListViewCart
        {
            get { return listViewCart; }
        }
        public List<string> GetOrderedItemNames()
        {
            List<string> orderedItemNames = new List<string>();

            foreach (ListViewItem item in listViewCart.Items)
            {
                string itemName = item.SubItems[1].Text; 
                orderedItemNames.Add(itemName);
            }

            return orderedItemNames;
        }
        private void listViewCart_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cart_Load(object sender, EventArgs e)
        {
           
            

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void SetLabelText()
        {
            label1.Text = SharedContext.Username;

        }
        private void SetLabel3Text()
        {

            label3.Text = CalculateTotalBill().ToString();

        }




        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            businesssapp.shopping shop = new businesssapp.shopping();
            shop.ShowDialog();
        }


        private List<ComboBox> comboBoxes = new List<ComboBox>();

       
        public List<CartItem> AddItemsToListView()
        {
            string username = SharedContext.Username;
            int id = SharedContext.Userid;
            List<CartItem> items = objecthandler.getcart().PopulateCart(username, id);


            listViewCart.Items.Clear();
            comboBoxes.Clear(); 

           

            foreach (CartItem item in items)
            {
              
                ListViewItem listItem = new ListViewItem(item.itemid.ToString());
                listItem.SubItems.Add(item.Name);
                listItem.SubItems.Add(item.Price.ToString());

                if (item.HasColorOptions)
                {
                    ComboBox comboBoxColors;
                    int comboBoxIndex = comboBoxes.FindIndex(c => c.Tag.Equals(item.itemid));
                   
                    if (comboBoxIndex != -1)
                    {
                        comboBoxColors = comboBoxes[comboBoxIndex];
                       
                        comboBoxColors.Items.Clear();
                        comboBoxColors.Items.AddRange(item.AvailableColors.ToArray());
                    }
                    else
                    {
                      
                        comboBoxColors = new ComboBox();
                        comboBoxColors.Tag = item.itemid; 
                        comboBoxColors.DropDownStyle = ComboBoxStyle.DropDownList;
                        comboBoxColors.Items.AddRange(item.AvailableColors.ToArray());
                        comboBoxColors.SelectedIndexChanged += (sender, e) =>
                        {
                            string selectedColor = comboBoxColors.SelectedItem?.ToString(); 
                                                                                            
                            objecthandler.getcart().UpdateColor(item.itemid, selectedColor);
                        };
                        comboBoxes.Add(comboBoxColors); 
                    }

                   
                    listItem.SubItems.Add(""); 
                    listViewCart.Items.Add(listItem);

                    // Position the ComboBox within the ListView
                    Rectangle bounds = listViewCart.GetItemRect(listViewCart.Items.Count - 1);
                    comboBoxColors.Size = new Size(listViewCart.Columns[3].Width, bounds.Height); 
                    comboBoxColors.Location = new Point(listViewCart.Columns[0].Width + listViewCart.Columns[1].Width + listViewCart.Columns[2].Width, bounds.Y);
                    listViewCart.Controls.Add(comboBoxColors);
                }
                else
                {
                   
                    string singleColor = item.AvailableColors.FirstOrDefault();
                    if (singleColor != null)
                    {
                        listItem.SubItems.Add(singleColor);
                    }
                    else
                    {
                        listItem.SubItems.Add(""); 
                    }
                    listViewCart.Items.Add(listItem);
                }

               
            }

            return items;
        }
        private bool firstButtonClicked = false;
        private void button1_Click(object sender, EventArgs e)
        {

            if (AllColorOptionsSelected())
            {
                ConfirmOrder();
                SetLabel3Text();
                firstButtonClicked = true;
            }
            else
            {
                MessageBox.Show("Please select colors for all items with color options before confirming the order.");
            }

        }



        public bool AllColorOptionsSelected()
        {
            foreach (var comboBox in comboBoxes)
            {
                if (comboBox.Visible && comboBox.SelectedItem == null)
                {
                    return false;
                }
            }
            return true;
        }

        private void ConfirmOrder()
        {
            string username = SharedContext.Username;
            float totalBill = CalculateTotalBill();
            MessageBox.Show($"Dear Customer {username}, Your total bill is: {totalBill}");
        }

        public float CalculateTotalBill()
        {
            float totalBill = 0;

           
            foreach (ListViewItem listItem in listViewCart.Items)
            {
               
                if (float.TryParse(listItem.SubItems[2].Text, out float itemPrice))
                {
                    totalBill += itemPrice;
                }
            }

            return totalBill;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listViewCart.SelectedItems.Count > 0)
            {

                ListViewItem selectedItem = listViewCart.SelectedItems[0];


                int selectedIndex = selectedItem.Index;


                listViewCart.Items.Remove(selectedItem);
                string username = SharedContext.Username;
                int id = SharedContext.Userid;
                List<CartItem> items = objecthandler.getcart().PopulateCart(username, id);

                if (selectedIndex >= 0 && selectedIndex < items.Count)
                {
                    // Remove the item from the list
                    items.RemoveAt(selectedIndex);


                    if (selectedIndex < listViewCart.Controls.Count)
                    {
                        Control control = listViewCart.Controls[selectedIndex];
                        listViewCart.Controls.Remove(control);
                        control.Dispose();
                    }
                }
                int itemId = int.Parse(selectedItem.SubItems[0].Text);
                MessageBox.Show(selectedItem.SubItems[0].Text);
                objecthandler.getcart().DeleteItemFromStorage(itemId);


                float totalBill = CalculateTotalBill();

            }
            else
            {
                MessageBox.Show("Please select an item to delete.");
            }
        }
        public List<CartItem> GetRemainingItems()
        {
            List<CartItem> remainingItems = new List<CartItem>();

            foreach (ListViewItem item in listViewCart.Items)
            {
                int itemId = int.Parse(item.SubItems[0].Text); 
                string name = item.SubItems[1].Text; 
                float price = float.Parse(item.SubItems[2].Text); 
                string selectedColor = item.SubItems[3].Text; 


                CartItem cartItem = new CartItem(itemId, name, price, selectedColor);
                remainingItems.Add(cartItem);
            }

            return remainingItems;
        }
        private void transfertolibrary()
        {
            List<CartItem> cartItems = GetRemainingItems();
            confirmedOrderBL confirmedOrder = new confirmedOrderBL();
            string username = SharedContext.Username;
            int id = objecthandler.getsignup().GetUserID(username);
            confirmedOrder.AddCartItemsToConfirmedOrder(cartItems, username, id);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (!firstButtonClicked)
            {

                MessageBox.Show("Please click the confirm before clicking the second button.");
                return;
            }
            transfertolibrary();
           

            this.Hide();
            payment pay = new payment();
          
            pay.ShowDialog();
        }
    }
}