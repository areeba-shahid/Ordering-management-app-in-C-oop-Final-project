﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class seeallusers : Form
    {
        public seeallusers()
        {
            InitializeComponent();
            Initializeallusers();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu cos = new adminmenu();
            cos.ShowDialog();
        }
        private void Initializeallusers()
        {
            List<signupBL> userlist = objecthandler.getsignup().getall();

            foreach (signupBL homedecitem in userlist)
            {
                ListViewItem item = new ListViewItem(homedecitem.getid().ToString());

                item.SubItems.Add(homedecitem.getname().ToString());


                item.SubItems.Add(homedecitem.getpass().ToString());
                item.SubItems.Add(homedecitem.getroll().ToString());



                listView1.Items.Add(item);


            }
            userlist.Clear();
        }

        private void seeallusers_Load(object sender, EventArgs e)
        {

        }
    }
}
