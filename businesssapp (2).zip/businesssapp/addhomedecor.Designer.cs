﻿namespace businesssapp
{
    partial class addhomedecor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.material = new System.Windows.Forms.Label();
            this.materialtxt = new System.Windows.Forms.TextBox();
            this.exit = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Button();
            this.typetxt = new System.Windows.Forms.TextBox();
            this.companytxt = new System.Windows.Forms.TextBox();
            this.warrantytxt = new System.Windows.Forms.TextBox();
            this.availtxt = new System.Windows.Forms.TextBox();
            this.domtxt = new System.Windows.Forms.TextBox();
            this.doetxt = new System.Windows.Forms.TextBox();
            this.costtxt = new System.Windows.Forms.TextBox();
            this.coloroptxt = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.warranty = new System.Windows.Forms.Label();
            this.doe = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.Label();
            this.company = new System.Windows.Forms.Label();
            this.color = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.Label();
            this.availibility = new System.Windows.Forms.Label();
            this.dom = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.quantitytxt = new System.Windows.Forms.TextBox();
            this.dimensiontxt = new System.Windows.Forms.TextBox();
            this.dimensions = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(234, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(395, 45);
            this.label5.TabIndex = 57;
            this.label5.Text = "Add new Home Decor";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // material
            // 
            this.material.AutoSize = true;
            this.material.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.material.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.material.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.material.Location = new System.Drawing.Point(412, 127);
            this.material.Name = "material";
            this.material.Size = new System.Drawing.Size(110, 20);
            this.material.TabIndex = 60;
            this.material.Text = "Add Material  :";
            // 
            // materialtxt
            // 
            this.materialtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.materialtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.materialtxt.Location = new System.Drawing.Point(557, 129);
            this.materialtxt.Name = "materialtxt";
            this.materialtxt.Size = new System.Drawing.Size(154, 20);
            this.materialtxt.TabIndex = 71;
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.exit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.exit.Location = new System.Drawing.Point(594, 160);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(157, 57);
            this.exit.TabIndex = 80;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.add.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.add.Location = new System.Drawing.Point(416, 160);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(157, 57);
            this.add.TabIndex = 81;
            this.add.Text = "Add New Product To inventory";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // typetxt
            // 
            this.typetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.typetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.typetxt.Location = new System.Drawing.Point(221, 90);
            this.typetxt.Name = "typetxt";
            this.typetxt.Size = new System.Drawing.Size(154, 20);
            this.typetxt.TabIndex = 148;
            // 
            // companytxt
            // 
            this.companytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.companytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.companytxt.Location = new System.Drawing.Point(221, 118);
            this.companytxt.Name = "companytxt";
            this.companytxt.Size = new System.Drawing.Size(154, 20);
            this.companytxt.TabIndex = 147;
            // 
            // warrantytxt
            // 
            this.warrantytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.warrantytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.warrantytxt.Location = new System.Drawing.Point(221, 313);
            this.warrantytxt.Name = "warrantytxt";
            this.warrantytxt.Size = new System.Drawing.Size(154, 20);
            this.warrantytxt.TabIndex = 146;
            // 
            // availtxt
            // 
            this.availtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.availtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.availtxt.Location = new System.Drawing.Point(221, 213);
            this.availtxt.Name = "availtxt";
            this.availtxt.Size = new System.Drawing.Size(154, 20);
            this.availtxt.TabIndex = 145;
            // 
            // domtxt
            // 
            this.domtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.domtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.domtxt.Location = new System.Drawing.Point(221, 248);
            this.domtxt.Name = "domtxt";
            this.domtxt.Size = new System.Drawing.Size(154, 20);
            this.domtxt.TabIndex = 144;
            // 
            // doetxt
            // 
            this.doetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.doetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doetxt.Location = new System.Drawing.Point(221, 285);
            this.doetxt.Name = "doetxt";
            this.doetxt.Size = new System.Drawing.Size(154, 20);
            this.doetxt.TabIndex = 143;
            // 
            // costtxt
            // 
            this.costtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.costtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.costtxt.Location = new System.Drawing.Point(221, 180);
            this.costtxt.Name = "costtxt";
            this.costtxt.Size = new System.Drawing.Size(154, 20);
            this.costtxt.TabIndex = 142;
            // 
            // coloroptxt
            // 
            this.coloroptxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.coloroptxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.coloroptxt.Location = new System.Drawing.Point(221, 147);
            this.coloroptxt.Name = "coloroptxt";
            this.coloroptxt.Size = new System.Drawing.Size(154, 20);
            this.coloroptxt.TabIndex = 141;
            // 
            // nametxt
            // 
            this.nametxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.nametxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.nametxt.Location = new System.Drawing.Point(221, 64);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(154, 20);
            this.nametxt.TabIndex = 140;
            // 
            // warranty
            // 
            this.warranty.AutoSize = true;
            this.warranty.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.warranty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warranty.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.warranty.Location = new System.Drawing.Point(24, 311);
            this.warranty.Name = "warranty";
            this.warranty.Size = new System.Drawing.Size(174, 20);
            this.warranty.TabIndex = 139;
            this.warranty.Text = "Add Warranty (in years)";
            // 
            // doe
            // 
            this.doe.AutoSize = true;
            this.doe.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.doe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doe.Location = new System.Drawing.Point(26, 281);
            this.doe.Name = "doe";
            this.doe.Size = new System.Drawing.Size(129, 20);
            this.doe.TabIndex = 138;
            this.doe.Text = "Add Date Expire:";
            // 
            // type
            // 
            this.type.AutoSize = true;
            this.type.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.type.Location = new System.Drawing.Point(26, 94);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(88, 20);
            this.type.TabIndex = 137;
            this.type.Text = "Add Type  :";
            // 
            // company
            // 
            this.company.AutoSize = true;
            this.company.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.company.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.company.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.company.Location = new System.Drawing.Point(26, 116);
            this.company.Name = "company";
            this.company.Size = new System.Drawing.Size(117, 20);
            this.company.TabIndex = 136;
            this.company.Text = "Add Company :";
            // 
            // color
            // 
            this.color.AutoSize = true;
            this.color.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.color.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.color.Location = new System.Drawing.Point(27, 147);
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(146, 20);
            this.color.TabIndex = 135;
            this.color.Text = "Add Color Options :";
            // 
            // Cost
            // 
            this.Cost.AutoSize = true;
            this.Cost.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cost.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Cost.Location = new System.Drawing.Point(27, 178);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(83, 20);
            this.Cost.TabIndex = 134;
            this.Cost.Text = "Add Cost :";
            // 
            // availibility
            // 
            this.availibility.AutoSize = true;
            this.availibility.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.availibility.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.availibility.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.availibility.Location = new System.Drawing.Point(27, 211);
            this.availibility.Name = "availibility";
            this.availibility.Size = new System.Drawing.Size(116, 20);
            this.availibility.TabIndex = 133;
            this.availibility.Text = "Add Availibility :";
            // 
            // dom
            // 
            this.dom.AutoSize = true;
            this.dom.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dom.Location = new System.Drawing.Point(24, 246);
            this.dom.Name = "dom";
            this.dom.Size = new System.Drawing.Size(193, 20);
            this.dom.TabIndex = 132;
            this.dom.Text = "Add Date of manufacture ";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.name.Location = new System.Drawing.Point(27, 64);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(90, 20);
            this.name.TabIndex = 131;
            this.name.Text = "Add name :";
            // 
            // quantitytxt
            // 
            this.quantitytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quantitytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.quantitytxt.Location = new System.Drawing.Point(557, 96);
            this.quantitytxt.Name = "quantitytxt";
            this.quantitytxt.Size = new System.Drawing.Size(154, 20);
            this.quantitytxt.TabIndex = 152;
            // 
            // dimensiontxt
            // 
            this.dimensiontxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dimensiontxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dimensiontxt.Location = new System.Drawing.Point(557, 66);
            this.dimensiontxt.Name = "dimensiontxt";
            this.dimensiontxt.Size = new System.Drawing.Size(154, 20);
            this.dimensiontxt.TabIndex = 151;
            // 
            // dimensions
            // 
            this.dimensions.AutoSize = true;
            this.dimensions.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dimensions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dimensions.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dimensions.Location = new System.Drawing.Point(412, 64);
            this.dimensions.Name = "dimensions";
            this.dimensions.Size = new System.Drawing.Size(129, 20);
            this.dimensions.TabIndex = 150;
            this.dimensions.Text = "Add Dimensions:";
            // 
            // quantity
            // 
            this.quantity.AutoSize = true;
            this.quantity.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantity.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.quantity.Location = new System.Drawing.Point(412, 94);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(101, 20);
            this.quantity.TabIndex = 149;
            this.quantity.Text = "Add Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(20, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 45);
            this.label1.TabIndex = 153;
            this.label1.Text = "Admin :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // addhomedecor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::businesssapp.Properties.Resources.home;
            this.ClientSize = new System.Drawing.Size(800, 354);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quantitytxt);
            this.Controls.Add(this.dimensiontxt);
            this.Controls.Add(this.dimensions);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.typetxt);
            this.Controls.Add(this.companytxt);
            this.Controls.Add(this.warrantytxt);
            this.Controls.Add(this.availtxt);
            this.Controls.Add(this.domtxt);
            this.Controls.Add(this.doetxt);
            this.Controls.Add(this.costtxt);
            this.Controls.Add(this.coloroptxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.warranty);
            this.Controls.Add(this.doe);
            this.Controls.Add(this.type);
            this.Controls.Add(this.company);
            this.Controls.Add(this.color);
            this.Controls.Add(this.Cost);
            this.Controls.Add(this.availibility);
            this.Controls.Add(this.dom);
            this.Controls.Add(this.name);
            this.Controls.Add(this.add);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.materialtxt);
            this.Controls.Add(this.material);
            this.Controls.Add(this.label5);
            this.Name = "addhomedecor";
            this.Text = "addhomedecor";
            this.Load += new System.EventHandler(this.addhomedecor_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label material;
        private System.Windows.Forms.TextBox materialtxt;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox typetxt;
        private System.Windows.Forms.TextBox companytxt;
        private System.Windows.Forms.TextBox warrantytxt;
        private System.Windows.Forms.TextBox availtxt;
        private System.Windows.Forms.TextBox domtxt;
        private System.Windows.Forms.TextBox doetxt;
        private System.Windows.Forms.TextBox costtxt;
        private System.Windows.Forms.TextBox coloroptxt;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label warranty;
        private System.Windows.Forms.Label doe;
        private System.Windows.Forms.Label type;
        private System.Windows.Forms.Label company;
        private System.Windows.Forms.Label color;
        private System.Windows.Forms.Label Cost;
        private System.Windows.Forms.Label availibility;
        private System.Windows.Forms.Label dom;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.TextBox quantitytxt;
        private System.Windows.Forms.TextBox dimensiontxt;
        private System.Windows.Forms.Label dimensions;
        private System.Windows.Forms.Label quantity;
        private System.Windows.Forms.Label label1;
    }
}