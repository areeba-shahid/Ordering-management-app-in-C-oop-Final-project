﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class seeallproducts : Form
    {
        public seeallproducts()
        {
            InitializeComponent();
            InitializeProductListofelectronics();
            InitializeProductListofcosmetics();
            InitializeProductListofhomedecor();


        }

        private void seeallproducts_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu cos = new adminmenu();
            cos.ShowDialog();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void InitializeProductListofelectronics()
        {

            List<products> electroniclist = objecthandler.getelectronic().showallproducts();
            foreach (electronics electronicitem in electroniclist)
            {
                ListViewItem item = new ListViewItem(electronicitem.getname());
                item.SubItems.Add(electronicitem.getcost().ToString()); // Format price as currency


                item.SubItems.Add(electronicitem.getcompany());
                item.SubItems.Add(string.Join(",", electronicitem.getcolor()));
                item.SubItems.Add(electronicitem.getType());
                item.SubItems.Add(electronicitem.getdateofmanufacture().ToShortDateString());
                item.SubItems.Add(electronicitem.getdateofexpire().ToShortDateString());
                item.SubItems.Add(electronicitem.getwarrantyDuration().ToString());
                item.SubItems.Add(string.Join(",", electronicitem.getdimensions())); // Assuming Dimensions is an array




                listView1.Items.Add(item);


            }
            electroniclist.Clear();
        }
        public void InitializeProductListofcosmetics()
        {

            List<products> cosmeticlist = objecthandler.getcosmetic().showallproducts();
            foreach (cosmetics cosmeticitem in cosmeticlist)
            {
                ListViewItem item = new ListViewItem(cosmeticitem.getname());
                item.SubItems.Add(cosmeticitem.getcost().ToString()); // Format price as currency


                item.SubItems.Add(cosmeticitem.getcompany());
                item.SubItems.Add(string.Join(",", cosmeticitem.getcolor()));
                item.SubItems.Add(cosmeticitem.getType());
                item.SubItems.Add(cosmeticitem.getdateofmanufacture().ToShortDateString());
                item.SubItems.Add(cosmeticitem.getdateofexpire().ToShortDateString());
                item.SubItems.Add(cosmeticitem.getwarrantyDuration().ToString());
                item.SubItems.Add(string.Join(",", cosmeticitem.getdimensions())); // Assuming Dimensions is an array


                listView1.Items.Add(item);


            }
            cosmeticlist.Clear();
        }

        public void InitializeProductListofhomedecor()
        {

            List<products> homedecorlist = objecthandler.gethomedecor().showallproducts();
            foreach (homeDecor homedecitem in homedecorlist)
            {
                ListViewItem item = new ListViewItem(homedecitem.getname());
                item.SubItems.Add(homedecitem.getcost().ToString()); // Format price as currency


                item.SubItems.Add(homedecitem.getcompany());
                item.SubItems.Add(string.Join(",", homedecitem.getcolor()));
                item.SubItems.Add(homedecitem.getType());
                item.SubItems.Add(homedecitem.getdateofmanufacture().ToShortDateString());
                item.SubItems.Add(homedecitem.getdateofexpire().ToShortDateString());
                item.SubItems.Add(homedecitem.getwarrantyDuration().ToString());
                item.SubItems.Add(string.Join(",", homedecitem.getdimensions())); // Assuming Dimensions is an array


                listView1.Items.Add(item);


            }
            homedecorlist.Clear();
        }

    }
}
