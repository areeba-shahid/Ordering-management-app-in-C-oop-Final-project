﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class setpaymentmethods : Form
    {
        public setpaymentmethods()
        {
            InitializeComponent();
        }
        payment pay = new payment();
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string text1 = textBox1.Text;

           
            pay.settext1(text1);
        }

        private void setpaymentmethods_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string text2 = textBox2.Text;
            
           
            pay.settext2(text2);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string text3 = textBox3.Text;


            pay.settext3(text3);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("updated");
            this.Hide();
            adminmenu pay = new adminmenu();
            pay.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu pay = new adminmenu();
            pay.ShowDialog();
        }
    }
}
