﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace businesssapp
{
    public partial class returning : Form
    {
       
        public returning()
        {
           
            InitializeComponent();
            setlabet1text();
           
            AddItemsToListView();
            AddItemsToListViewreturn();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           

        }
        private void setlabet1text()
        {
            string name = SharedContext.Username;
            label1.Text = name;
        }
        public void AddItemsToListView()
        {
            string name = SharedContext.Username;
            int id = objecthandler.getsignup().GetUserID(name);
           List<ReturnItem> items =  objecthandler.getreturn().retrievedata(name, id);
           
           
            PopulateListView(items);
            items.Clear();
        }
        public void PopulateListView(List<ReturnItem> items)
        {
           
            listViewCart.Items.Clear();

           

          
            foreach (var item in items)
            {
                ListViewItem listViewItem = new ListViewItem(item.ItemId.ToString());
                listViewItem.SubItems.Add(item.getname());
                
                listViewItem.SubItems.Add(item.getcost().ToString());
                listViewItem.SubItems.Add(item.Color);
                listViewItem.SubItems.Add(item.getcompany());
                listViewItem.SubItems.Add(item.getType());

                listViewCart.Items.Add(listViewItem);
            }
            items.Clear();
        }

       

       
    


    private void returning_Load(object sender, EventArgs e)
        {

        }

        List<ReturnItem> selectedItems = new List<ReturnItem>();

        // Handle ListView item selection
        private void listViewCart_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if any item is selected
            if (listViewCart.SelectedItems.Count > 0)
            {
                // Clear previously selected items
                selectedItems.Clear();

                // Add selected item(s) to the list
                foreach (ListViewItem selectedItem in listViewCart.SelectedItems)
                {
                    // Retrieve item details from ListView and add to selectedItems list
                    int itemId = int.Parse(selectedItem.SubItems[0].Text);
                    SharedContext._itemid = itemId;
                  
                    string name = selectedItem.SubItems[1].Text;
                    float cost = float.Parse(selectedItem.SubItems[2].Text);
                    string color = selectedItem.SubItems[3].Text;
                    string company = selectedItem.SubItems[4].Text;
                    string type = selectedItem.SubItems[5].Text;

                    // Create a ReturnItem object and add to selectedItems list
                    ReturnItem item = new ReturnItem(itemId, name, color, cost, company, type);
                    selectedItems.Add(item);
                }
            }
        }
        public void AddItemsToListViewreturn()
        {
            string name = SharedContext.Username;
            int id = objecthandler.getsignup().GetUserID(name);
            List<ReturnItem> returningitems = objecthandler.getreturn().PopulateListViewWithReturnedProducts(id, name);

            // Now you have the list of items, you can use it to populate your list view
            PopulateListViewreturn(returningitems);
            returningitems.Clear();
        }

        public void PopulateListViewreturn(List<ReturnItem> returningitems)
        {
            // Clear existing items in the ListView
            listViewreturn.Items.Clear();



            // Add items to the ListView
            foreach (var item in returningitems)
            {
                ListViewItem listViewItem = new ListViewItem(item.ItemId.ToString());
                listViewItem.SubItems.Add(item.getname());

                listViewItem.SubItems.Add(item.getcost().ToString());
                listViewItem.SubItems.Add(item.Color);
                listViewItem.SubItems.Add(item.getcompany());
                listViewItem.SubItems.Add(item.getType());

                listViewreturn.Items.Add(listViewItem);
            }
            returningitems.Clear();
        }
        private void confirmButton_Click(object sender, EventArgs e)
        {
            if (selectedItems.Count > 0)
            {
                //function call idhr krna list empty krny sy pehly
                // store in fh and db
                // gridview to see return for user 
                // delete from bought items 
                // delete from return listview
                foreach (ListViewItem selectedItem in listViewCart.SelectedItems)
                {
                    // Remove the selected item from listViewCart
                    listViewCart.Items.Remove(selectedItem);
                }

                string name = SharedContext.Username;
                int id = objecthandler.getsignup().GetUserID(name);
                objecthandler.getreturn().WriteReturnedItems(selectedItems, id, name);
      
                
         objecthandler.getreturn().RemoveProductFromBoughtItems(SharedContext._itemid, name);
              


                selectedItems.Clear();
                MessageBox.Show("Your return request has been confirmed");
                exit();
            }
        }
      

        private void cancelButton_Click(object sender, EventArgs e)
        {
            selectedItems.Clear();
            MessageBox.Show("No items for return selected");
            exit();
        }
        private void exit()
        {
           
            listViewCart.Clear();
           
            this.Hide();
            customermenu c = new customermenu();
            c.ShowDialog();
        }
        private void selectbtm_Click(object sender, EventArgs e)
        {
           
        }

        private void listViewreturn_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
      

    }
}
