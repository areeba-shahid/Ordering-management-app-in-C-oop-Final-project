﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class setdeliveryfee : Form
    {
        public setdeliveryfee()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string fees = textBox1.Text;
            int fee = Convert.ToInt32(fees);
            payment pay = new payment();
            pay.setfee(fee);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu pay = new adminmenu();
            pay.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("updated");
            this.Hide();
            adminmenu pay = new adminmenu();
            pay.ShowDialog();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string fees = textBox2.Text;
            int fee = Convert.ToInt32(fees);
            payment pay = new payment();
            pay.setcodfee(fee);
        }

        private void setdeliveryfee_Load(object sender, EventArgs e)
        {

        }
    }
}
