﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class customermenu : Form
    {
        public customermenu()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            electronicsshow electronics = new electronicsshow();
            electronics.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            showcosmetics cosmetic = new showcosmetics();
            cosmetic.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            showhomedecor home = new showhomedecor();
            home.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            shopping shop = new shopping();
            shop.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            cart carts = new cart();
            carts.ShowDialog();
        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            returning returned = new returning();
            returned.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
           login log = new login();
            log.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            editcredentials edited = new editcredentials();
            edited.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            businesssapp.login log = new businesssapp.login();
            log.ShowDialog();
        }

        private void customermenu_Load(object sender, EventArgs e)
        {

        }
    }
}
