﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace businesssapp
{
    public partial class payment : Form
    {
       
        public payment()
        {
            InitializeComponent();
            setfeelabel();
            setcheckbox1text();
            setcheckbox2text();
            setcheckbox3text();



            setlabel7text();
            setlabel11text();
            checkBox1.CheckedChanged += checkBox_CheckedChanged;
            checkBox2.CheckedChanged += checkBox_CheckedChanged;
            checkBox3.CheckedChanged += checkBox_CheckedChanged;
        }
       
        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox clickedCheckBox = (CheckBox)sender;

          
            if (clickedCheckBox.Checked)
            {
               
                foreach (Control control in Controls)
                {
                    if (control is CheckBox checkBox && checkBox != clickedCheckBox)
                    {
                        checkBox.Checked = false;
                    }
                }
            }
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            
        }
       private void setlabel7text()
        {
            cart carts = new cart();
            label7.Text = carts.CalculateTotalBill().ToString();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
        private static float deliveryfee;
        public void setfee(float fee)
        {
            deliveryfee = fee;
          
            

        }
        public float getfee()
        {
            if (deliveryfee == 0)
            {
                deliveryfee = 150;
            }
           
            return deliveryfee;
        }
        private static float codfee;
        public void setcodfee(float fee)
        {
            codfee = fee;



        }
        public float getcodfee()
        {
            if (codfee == 0)
            {
                codfee = 50;
            }

            return codfee;
        }


        private static string text1;
        private static string text2;
        private static string text3;
        public void settext1(string text)
        {
            text1 = text;
           


        }
        public string gettext1()
        {
            if (text1 == null)
            {
                text1 = "Payment On Home Delivery (includes cash payement fee)";
            }

            return text1;
        }
        public void settext2(string text)
        {
            text2 = text;



        }
        public string gettext2()
        {
            if (text2 == null)
            {
                text2 = "Jazzcash Payment";
            }

            return text2;
        }
        public void settext3(string text)
        {
            text3 = text;



        }
        public string gettext3()
        {
            if (text3 == null)
            {
                text3 = "Credit Card payment";
            }

            return text3;
        }
        private void setcheckbox1text()
        {
            checkBox1.Text = gettext1();
        }
        private void setcheckbox2text()
        {
            checkBox2.Text = gettext2();
        }
        private void setcheckbox3text()
        {
            checkBox3.Text =gettext3();
        }

        private float setlabel11text()
        {
            cart carts = new cart();
            float price = carts.CalculateTotalBill();
            price = price + getfee();
            label11.Text = price.ToString();
            return price;
        }
        private string GetPaymentMethod()
        {
            if (checkBox1.Checked)
            {
                return "Cash on Delivery";
            }
            else if (checkBox2.Checked)
            {
                return "JazzCash";
            }
            else if (checkBox3.Checked)
            {
                return "Credit Card";
            }
            else
            {
               
                return null;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                
                UpdateLabel1Text(getcodfee());
            }
            else
            {
               
                UpdateLabel1Text(0);
            }
        }
        public void UpdateLabel1Text(float additionalAmount)
        {
            float price = setlabel11text();
            price += additionalAmount; 

          
            label11.Text = price.ToString();
            CustomerBL.SetBill(price);


        }

        private void payment_Load(object sender, EventArgs e)
        {
           


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            customermenu customer = new customermenu();
            customer.ShowDialog();
        }
        private void trasfertodb()
        {
            string username = SharedContext.Username;
            int id = objecthandler.getsignup().GetUserID(username);
            float bill = float.Parse(label11.Text);
            string paymentmethod = GetPaymentMethod();
            cart cart1 = new cart();
        


            List<string> orderedItemNames = cart1.GetOrderedItemNames();
            string concatenatedItems = string.Join(", ", orderedItemNames);
            objecthandler.getpayment().storepaymentrecord(username, id, bill, paymentmethod, concatenatedItems);
        }
        private void button1_Click(object sender, EventArgs e)
        {

          
            bool check = checkboxconstarint();
            if (check == true)
            {
                trasfertodb();
                DataTable dataTable = objecthandler.getcart().RetrieveDataFromBoughtRecently();
                objecthandler.getcart().InsertDataIntoBought(dataTable);
                objecthandler.getcart().DeleteAllDataFromBoughtRecently();
                MessageBox.Show("YOUR ORDER HAS BEEN CONFIRMED");
                this.Hide();
                customermenu cus = new customermenu();
                cus.ShowDialog();
            }
            else
            {

            }
           
        }

        private bool checkboxconstarint()
        {
            bool check = true;
            if (!checkBox1.Checked && !checkBox2.Checked && !checkBox3.Checked)
            {
               
                MessageBox.Show("Please select at least one checkbox.");
                check = false;
            }
            return check;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }
       
      


       

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }
        private void setfeelabel()
        {
            label2.Text = getfee().ToString();
        }

        
    }
}
