﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using businessapplibrary;

namespace businesssapp
{
    public partial class showcosmetics : Form
    {
        public showcosmetics()
        {
            InitializeComponent();
        }
        DataTable dataTable = new DataTable();
       
        private TrackBar slider;
        private Label pageLabel;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cosmetics_Load(object sender, EventArgs e)
        {

          
            dataTable.Columns.Add("Name", typeof(string));

            dataTable.Columns.Add("Company", typeof(string));

            dataTable.Columns.Add("Color", typeof(string));
            dataTable.Columns.Add("Cost", typeof(string));


            dataTable.Columns.Add("DateOfManufacture", typeof(DateTime));
            dataTable.Columns.Add("DateOfExpire", typeof(DateTime));

            dataTable.Columns.Add("WarrantyDuration", typeof(float));
            dataTable.Columns.Add("Dimensions", typeof(string));


            dataTable.Columns.Add("skintype", typeof(string));
            dataTable.Columns.Add("shade", typeof(string));

            dataTable.Columns.Add("packagingtype", typeof(string));


            dataGridView1.DataSource = dataTable;

            List<products> cosmeticsitems = objecthandler.getcosmetic().showallproducts();

            foreach(cosmetics cosmetic in cosmeticsitems)
            {
                dataTable.Rows.Add(cosmetic.getname(), cosmetic.getcompany(), cosmetic.getcolor(), cosmetic.getcost(),
                    cosmetic.getdateofmanufacture(), cosmetic.getdateofexpire(), cosmetic.getwarrantyDuration(), cosmetic.getdimensions(),
                 cosmetic.getskintype(), cosmetic.getshade(), cosmetic.getPackagingtype());

            }
            cosmeticsitems.Clear();
            dataGridView1.DataSource = dataTable;


            slider = new TrackBar();
            slider.Dock = DockStyle.Bottom;
            slider.Minimum = 1;
            slider.ValueChanged += Slider_ValueChanged;
            Controls.Add(slider);

           
            pageLabel = new Label();
            pageLabel.Dock = DockStyle.Bottom;
            Controls.Add(pageLabel);

           
            UpdateSlider();
        }
        private void UpdateSlider()
        {
           
            int totalPages = (int)Math.Ceiling((double)dataTable.Rows.Count / dataGridView1.DisplayedRowCount(false));
            slider.Maximum = totalPages > 0 ? totalPages : 1;
            slider.Value = 1;
            UpdatePageLabel();
        }

        private void UpdatePageLabel()
        {
            pageLabel.Text = $"Page {slider.Value} of {slider.Maximum}";
        }
        private void Slider_ValueChanged(object sender, EventArgs e)
        {
            int startIndex = (slider.Value - 1) * dataGridView1.DisplayedRowCount(false);
            int endIndex = Math.Min(startIndex + dataGridView1.DisplayedRowCount(false), dataTable.Rows.Count);

            DataTable displayTable = dataTable.Clone();
            for (int i = startIndex; i < endIndex; i++)
            {
                displayTable.ImportRow(dataTable.Rows[i]);
            }

            dataGridView1.DataSource = displayTable;
            UpdatePageLabel();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            businesssapp.customermenu cmenu = new businesssapp.customermenu();
            cmenu.ShowDialog();
        }
    }
}
