﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using businessapplibrary;

namespace businesssapp
{
    public class objecthandler
    {
       public static string conn = "Server=DESKTOP-BMODQLI;Database=businessapp;Trusted_connection=True";

         private static IsignupDL signup = signupDB.getInstance(conn);
       private static IproductsDL electronic = electronicDB.getInstance(conn);
       private static IproductsDL cosmetics = cosmeticDB.getInstance(conn);
       private static IproductsDL hdecors = homedecorDB.getInstance(conn);
       private static IcartDL cart = cartDB.getInstance(conn);
       private static IpaymentDL payment = paymentDB.getInstance(conn);
      private static IreturnDL returned = ReturnDB.getInstance(conn);

        /*     private static IsignupDL signup = new signupFH();
    private static IproductsDL electronic = new electronicFH();
    private static IproductsDL cosmetics = new cosmeticFH();
    private static IproductsDL hdecors = new homedecorFH();
      private static IpaymentDL payment = new paymentFH();
    private static IcartDL cart = new cartFH();
     private static IreturnDL returned = new ReturnFH();*/




        public static IsignupDL getsignup()
        {
            return signup;

        }
        public static IproductsDL getelectronic()
        {
            return electronic;

        }
        public static IreturnDL getreturn()
        {
            return returned;

        }
        public static IproductsDL getcosmetic()
        {
            return cosmetics;

        }
        public static IproductsDL gethomedecor()
        {
            return hdecors;

        }
        public static IcartDL getcart()
        {
            return cart;


        }
        public static IpaymentDL getpayment()
        {
            return payment;


        }

    }
}
