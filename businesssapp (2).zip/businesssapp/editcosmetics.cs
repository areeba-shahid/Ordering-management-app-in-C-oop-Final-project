﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace businesssapp
{
    public partial class editcosmetics : Form
    {
        public editcosmetics()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }
        DataTable dataTable = new DataTable();
        List<cosmetics> newcos = new List<cosmetics>();
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }

        private void editcosmetics_Load(object sender, EventArgs e)
        {
            dataTable.Columns.Add("Name", typeof(string));

            dataTable.Columns.Add("Company", typeof(string));

            dataTable.Columns.Add("Color", typeof(string));
            dataTable.Columns.Add("Cost", typeof(string));


            dataTable.Columns.Add("DateOfManufacture", typeof(DateTime));
            dataTable.Columns.Add("DateOfExpire", typeof(DateTime));

            dataTable.Columns.Add("WarrantyDuration", typeof(float));
            dataTable.Columns.Add("Dimensions", typeof(string));
            dataTable.Columns.Add("Quantity", typeof(string));

            dataTable.Columns.Add("skintype", typeof(string));
            dataTable.Columns.Add("shade", typeof(string));

            dataTable.Columns.Add("packagingtype", typeof(string));


            dataGridView1.DataSource = dataTable;

            List<products> cosmeticsitems = objecthandler.getcosmetic().showallproducts();

            foreach (cosmetics cosmetic in cosmeticsitems)
            {
                dataTable.Rows.Add(cosmetic.getname(), cosmetic.getcompany(), cosmetic.getcolor(), cosmetic.getcost(),
                    cosmetic.getdateofmanufacture(), cosmetic.getdateofexpire(), cosmetic.getwarrantyDuration(), cosmetic.getdimensions(),
                cosmetic.getquantity(), cosmetic.getskintype(), cosmetic.getshade(), cosmetic.getPackagingtype());

            }
            cosmeticsitems.Clear();
            dataGridView1.DataSource = dataTable;

        }
        private static int id;
        private void setid(string name, string company)
        {


            cosmeticDB el = new cosmeticDB(objecthandler.conn);
            id = el.retrieveid(name, company);

        }
        private int getid()
        {
            return id;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
          
            if (dataGridView1.SelectedRows.Count > 0)
            {
                
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

              
                string name = selectedRow.Cells["Name"].Value.ToString();
                string company = selectedRow.Cells["Company"].Value.ToString();
                string Color = selectedRow.Cells["Color"].Value.ToString();
                string cost = selectedRow.Cells["Cost"].Value.ToString();
                string dateofmanufacture = selectedRow.Cells["DateOfManufacture"].Value.ToString();
                string dateofexpire = selectedRow.Cells["DateOfExpire"].Value.ToString();
                string Warrantyduration = selectedRow.Cells["WarrantyDuration"].Value.ToString();
                string Dimensions = selectedRow.Cells["Dimensions"].Value.ToString();
                string quantity = selectedRow.Cells["Quantity"].Value.ToString(); ;
                string skintype = selectedRow.Cells["skintype"].Value.ToString();
                string shade = selectedRow.Cells["shade"].Value.ToString();
                string packagingtype = selectedRow.Cells["packagingtype"].Value.ToString();
                setid(name, company);


              
                nametxt.Text = name;
                companytxt.Text = company;
                coloroptxt.Text = Color;
                costtxt.Text = cost;
                domtxt.Text = dateofmanufacture;
                doetxt.Text = dateofexpire;

                warrantytxt.Text = Warrantyduration;
                dimensiontxt.Text = Dimensions;
                quantitytxt.Text = quantity;
                skintypetxt.Text = skintype;
                shadetxt.Text = shade;
                packagetxt.Text = packagingtype;

                
            }
            else
            {
                nametxt.Text = "";
                companytxt.Text = "";
                coloroptxt.Text = "";
                costtxt.Text = "";
                domtxt.Text = "";
                doetxt.Text = "";
                warrantytxt.Text = "";
                dimensiontxt.Text = "";
                quantitytxt.Text = "";
                skintypetxt.Text = "";
                shadetxt.Text = "";
                packagetxt.Text = "";
            }

        }
        public List<cosmetics> retrieveupdatedvalues()
        {
            string name = nametxt.Text; ;
            string type = "";
            string company = companytxt.Text;
            float cost = Convert.ToSingle(costtxt.Text);
            string[] color = coloroptxt.Text.Split(',');
            int availibility = 0;
            DateTime dateofmanufacture = Convert.ToDateTime(domtxt.Text);
            DateTime dateofexpire = Convert.ToDateTime(doetxt.Text);
            float warranty = Convert.ToSingle(warrantytxt.Text);
            string[] dimensions = dimensiontxt.Text.Split(',');
            float quantity = Convert.ToSingle(quantitytxt.Text);
            string skintype = skintypetxt.Text;

            string shade = shadetxt.Text;

            string packagintype = packagetxt.Text;


            cosmetics elec = new cosmetics(name, type, company, color, cost, availibility, dateofmanufacture, dateofexpire, warranty, dimensions, quantity, skintype, shade, packagintype);

            newcos.Add(elec);
            return newcos;
        }

        private void add_Click(object sender, EventArgs e)
        {
            List<cosmetics> topass = retrieveupdatedvalues();
            cosmeticDB ele = new cosmeticDB(objecthandler.conn);
            ele.updateindb(topass, getid());
            exit();
        }
        private void exit()
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }
    }
}
