﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class deletecosmetic : Form
    {
        public deletecosmetic()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }
        DataTable dataTable = new DataTable();
      
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void deletecosmetic_Load(object sender, EventArgs e)
        {
            dataTable.Columns.Add("Name", typeof(string));

            dataTable.Columns.Add("Company", typeof(string));

            dataTable.Columns.Add("Color", typeof(string));
            dataTable.Columns.Add("Cost", typeof(string));


            dataTable.Columns.Add("DateOfManufacture", typeof(DateTime));
            dataTable.Columns.Add("DateOfExpire", typeof(DateTime));

            dataTable.Columns.Add("WarrantyDuration", typeof(float));
            dataTable.Columns.Add("Dimensions", typeof(string));
            dataTable.Columns.Add("Quantity", typeof(string));


            dataTable.Columns.Add("skintype", typeof(string));
            dataTable.Columns.Add("shade", typeof(string));

            dataTable.Columns.Add("packagingtype", typeof(string));


            dataGridView1.DataSource = dataTable;

            List<products> cosmeticsitems = objecthandler.getcosmetic().showallproducts();

            foreach (cosmetics cosmetic in cosmeticsitems)
            {
                dataTable.Rows.Add(cosmetic.getname(), cosmetic.getcompany(), cosmetic.getcolor(), cosmetic.getcost(),
                    cosmetic.getdateofmanufacture(), cosmetic.getdateofexpire(), cosmetic.getwarrantyDuration(), cosmetic.getdimensions(),
               cosmetic.getquantity(),  cosmetic.getskintype(), cosmetic.getshade(), cosmetic.getPackagingtype());

            }
            cosmeticsitems.Clear();
            dataGridView1.DataSource = dataTable;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }
        private static int id;
        private void setid(string name, string company)
        {


            cosmeticDB el = new cosmeticDB(objecthandler.conn);
            id = el.retrieveid(name, company);

        }
        private int getid()
        {
            return id;
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
           
            if (dataGridView1.SelectedRows.Count > 0)
            {
               
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

               
                string name = selectedRow.Cells["Name"].Value.ToString();
                string company = selectedRow.Cells["Company"].Value.ToString();
                string Color = selectedRow.Cells["Color"].Value.ToString();
                string cost = selectedRow.Cells["Cost"].Value.ToString();
                string dateofmanufacture = selectedRow.Cells["DateOfManufacture"].Value.ToString();
                string dateofexpire = selectedRow.Cells["DateOfExpire"].Value.ToString();
                string Warrantyduration = selectedRow.Cells["WarrantyDuration"].Value.ToString();
                string Dimensions = selectedRow.Cells["Dimensions"].Value.ToString();
                string quantity = selectedRow.Cells["Quantity"].Value.ToString(); ;
                string skintype = selectedRow.Cells["skintype"].Value.ToString();
                string shade = selectedRow.Cells["shade"].Value.ToString();
                string packagingtype = selectedRow.Cells["packagingtype"].Value.ToString();
                setid(name, company);
            }
        }


        private void deleteRowFromDataGridView()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows.RemoveAt(selectedIndex);
            }
        }

        private void removeSelectedRecordFromDatabase()
        {
            int id = getid();
            cosmeticDB ele = new cosmeticDB(objecthandler.conn);
            ele.removefromdb(id);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            removeSelectedRecordFromDatabase();
            deleteRowFromDataGridView();

            MessageBox.Show("Item removed");
        }
    }
        }
