﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using businessapplibrary;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace businesssapp
{
    public partial class signin : Form
    {
        public string username;
       
      
       
        public signin()
        {
            InitializeComponent();
        }
        
        private void cleardatafromform()
        {
            nametextbox.Text = "";
            passtextBox.Text = "";
        }
       

        private void signin_Load(object sender, EventArgs e)
        {
           
        }
        

       
        private void exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            login log = new login();
            log.ShowDialog();
        }

      
      
    private void button1_Click(object sender, EventArgs e)
        {
            string username = nametextbox.Text;
            string password = passtextBox.Text;
            SharedContext.Username = nametextbox.Text;
            string roll = objecthandler.getsignup().GetRoll(username, password);
                bool check = false;
            if (roll == "Customer")
            {
                CustomerBL user = new CustomerBL(username, password);
                signupBL validuser = objecthandler.getsignup().signin(user);
                if (validuser != null)
                {
                   
                    check = true;
                }
            }
            else if (roll == "Admin")
            {
                AdminBL user = new AdminBL(username, password);
                signupBL validuser = objecthandler.getsignup().signin(user);
                if (validuser != null)
                {
                    
                    check = true;
                }
            }
            if (roll != null && check == true )
            {
                switch (roll)
                {
                    case "Customer":
                        this.username = nametextbox.Text;
                        SharedContext.Username = username;
                        this.Hide();
                        customermenu customer_menu = new customermenu();
                        customer_menu.ShowDialog();
                       
                        break;
                    case "Manager":
                        this.Hide();
                        managermenu manager_menu = new managermenu();
                        manager_menu.ShowDialog();
                        break;
                    case "Admin":
                        this.Hide();
                        adminmenu admin_menu = new adminmenu();
                        admin_menu.ShowDialog();
                        break;
                    default:
                        MessageBox.Show("Invalid roll");
                        break;
                }
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }
          
        }

    }
}