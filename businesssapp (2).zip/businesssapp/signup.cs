﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using businessapplibrary;


namespace businesssapp
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
           
        }
        
        private void cleardatafromform()
        {
            nametextbox.Text = "";
            passtextbox.Text = "";

        }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Password should be at least of 8 characters .u can use special characters and numbers as well . 1st character should be capital . Password of an user can not be assigned  to other user");
        }

        private void rolltextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passtextbox_TextChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            businesssapp.login log = new businesssapp.login();
            log.ShowDialog();
        }

        private void nametextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

      


        private void button4_Click(object sender, EventArgs e)
        {

            bool check = true;
            if (objecthandler.getsignup().validityofpassword(passtextbox.Text) && nametextbox.Text != null
               && objecthandler.getsignup().IsPasswordUnique(passtextbox.Text) && objecthandler.getsignup().IsusernameUnique(nametextbox.Text))
               
            {
                check = false;
            }
            if(check == true)
            {
                MessageBox.Show(" Input all valid credentials . ");
             
                cleardatafromform();
              
            }

        
          
            if (comboBox1.SelectedItem != null && check==false)
            {
                objecthandler.getsignup().storerespectively(nametextbox.Text,passtextbox.Text, comboBox1.SelectedItem.ToString());
                MessageBox.Show("Account Created!");
                cleardatafromform();
            }
           
        }

       

      

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
          
          

        }
        private void signup_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Admin");
            comboBox1.Items.Add("Customer");
           
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
