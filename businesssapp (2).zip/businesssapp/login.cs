﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using businessapplibrary;




namespace businesssapp
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            List<signupBL> userslist = objecthandler.getsignup().GetUsers();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            signup signsup = new signup();
           
           signsup.ShowDialog();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            signin signsin = new signin();
            signsin.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }
    }
}
