﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class deletehomedecor : Form
    {
        public deletehomedecor()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }
        DataTable dataTable = new DataTable();
      
        private void deletehomedecor_Load(object sender, EventArgs e)
        {
            dataTable.Columns.Add("Name", typeof(string));

            dataTable.Columns.Add("Company", typeof(string));

            dataTable.Columns.Add("Color", typeof(string));
            dataTable.Columns.Add("Cost", typeof(string));


            dataTable.Columns.Add("DateOfManufacture", typeof(DateTime));
            dataTable.Columns.Add("DateOfExpire", typeof(DateTime));

            dataTable.Columns.Add("WarrantyDuration", typeof(float));
            dataTable.Columns.Add("Dimensions", typeof(string));
            dataTable.Columns.Add("Quantity", typeof(string));

            dataTable.Columns.Add("material", typeof(string));


            dataGridView1.DataSource = dataTable;

            dataTable.Clear();
            List<products> hdecoritems = objecthandler.gethomedecor().showallproducts();

            foreach (homeDecor homedec in hdecoritems)
            {
                dataTable.Rows.Add(homedec.getname(), homedec.getcompany(), homedec.getcolor(), homedec.getcost(),
                    homedec.getdateofmanufacture(), homedec.getdateofexpire(), homedec.getwarrantyDuration(), homedec.getdimensions(),
             homedec.getquantity(), homedec.getmaterial());

            }
            hdecoritems.Clear();
            dataGridView1.DataSource = dataTable;


        }

        private static int id;
        private void setid(string name, string company)
        {


            homedecorDB el = new homedecorDB(objecthandler.conn);
            id = el.retrieveid(name, company);

        }
        private int getid()
        {
            return id;
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
           
            if (dataGridView1.SelectedRows.Count > 0)
            {
              
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

               
                string name = selectedRow.Cells["Name"].Value.ToString();
                string company = selectedRow.Cells["Company"].Value.ToString();
                string Color = selectedRow.Cells["Color"].Value.ToString();
                string cost = selectedRow.Cells["Cost"].Value.ToString();
                string dateofmanufacture = selectedRow.Cells["DateOfManufacture"].Value.ToString();
                string dateofexpire = selectedRow.Cells["DateOfExpire"].Value.ToString();
                string Warrantyduration = selectedRow.Cells["WarrantyDuration"].Value.ToString();
                string Dimensions = selectedRow.Cells["Dimensions"].Value.ToString();
                string quantity = selectedRow.Cells["Quantity"].Value.ToString(); ;
                string material = selectedRow.Cells["material"].Value.ToString();
             
                setid(name, company);






            }
        }

        private void deleteRowFromDataGridView()
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows.RemoveAt(selectedIndex);
            }
        }

        private void removeSelectedRecordFromDatabase()
        {
            int id = getid();
            homedecorDB ele = new homedecorDB(objecthandler.conn);
            ele.removefromdb(id);
        }
       

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            removeSelectedRecordFromDatabase();
            deleteRowFromDataGridView();

            MessageBox.Show("Item removed");
        }
    }
}
