﻿namespace businesssapp
{
    partial class addcosmetic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.Button();
            this.skintypetxt = new System.Windows.Forms.TextBox();
            this.shadetxt = new System.Windows.Forms.TextBox();
            this.packagetxt = new System.Windows.Forms.TextBox();
            this.add = new System.Windows.Forms.Button();
            this.skintype = new System.Windows.Forms.Label();
            this.package = new System.Windows.Forms.Label();
            this.shade = new System.Windows.Forms.Label();
            this.quantitytxt = new System.Windows.Forms.TextBox();
            this.typetxt = new System.Windows.Forms.TextBox();
            this.companytxt = new System.Windows.Forms.TextBox();
            this.warrantytxt = new System.Windows.Forms.TextBox();
            this.availtxt = new System.Windows.Forms.TextBox();
            this.domtxt = new System.Windows.Forms.TextBox();
            this.doetxt = new System.Windows.Forms.TextBox();
            this.costtxt = new System.Windows.Forms.TextBox();
            this.coloroptxt = new System.Windows.Forms.TextBox();
            this.dimensiontxt = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.warranty = new System.Windows.Forms.Label();
            this.dimensions = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.Label();
            this.doe = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.Label();
            this.company = new System.Windows.Forms.Label();
            this.color = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.Label();
            this.availibility = new System.Windows.Forms.Label();
            this.dom = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(244, 9);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(339, 45);
            this.label5.TabIndex = 56;
            this.label5.Text = "Add new Cosmetic";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.exit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.exit.Location = new System.Drawing.Point(631, 229);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(157, 57);
            this.exit.TabIndex = 82;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // skintypetxt
            // 
            this.skintypetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.skintypetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.skintypetxt.Location = new System.Drawing.Point(625, 123);
            this.skintypetxt.Name = "skintypetxt";
            this.skintypetxt.Size = new System.Drawing.Size(154, 20);
            this.skintypetxt.TabIndex = 88;
            // 
            // shadetxt
            // 
            this.shadetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.shadetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.shadetxt.Location = new System.Drawing.Point(625, 154);
            this.shadetxt.Name = "shadetxt";
            this.shadetxt.Size = new System.Drawing.Size(154, 20);
            this.shadetxt.TabIndex = 87;
            // 
            // packagetxt
            // 
            this.packagetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.packagetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.packagetxt.Location = new System.Drawing.Point(625, 185);
            this.packagetxt.Name = "packagetxt";
            this.packagetxt.Size = new System.Drawing.Size(154, 20);
            this.packagetxt.TabIndex = 86;
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.add.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.add.Location = new System.Drawing.Point(461, 229);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(157, 57);
            this.add.TabIndex = 81;
            this.add.Text = "Add New Product To inventory";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // skintype
            // 
            this.skintype.AutoSize = true;
            this.skintype.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.skintype.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skintype.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.skintype.Location = new System.Drawing.Point(457, 123);
            this.skintype.Name = "skintype";
            this.skintype.Size = new System.Drawing.Size(112, 20);
            this.skintype.TabIndex = 83;
            this.skintype.Text = "Add skintype  :";
            // 
            // package
            // 
            this.package.AutoSize = true;
            this.package.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.package.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.package.Location = new System.Drawing.Point(457, 181);
            this.package.Name = "package";
            this.package.Size = new System.Drawing.Size(162, 20);
            this.package.TabIndex = 84;
            this.package.Text = "Add Packaging Type :";
            // 
            // shade
            // 
            this.shade.AutoSize = true;
            this.shade.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.shade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shade.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.shade.Location = new System.Drawing.Point(457, 154);
            this.shade.Name = "shade";
            this.shade.Size = new System.Drawing.Size(97, 20);
            this.shade.TabIndex = 85;
            this.shade.Text = "Add  Shade:";
            // 
            // quantitytxt
            // 
            this.quantitytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quantitytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.quantitytxt.Location = new System.Drawing.Point(625, 91);
            this.quantitytxt.Name = "quantitytxt";
            this.quantitytxt.Size = new System.Drawing.Size(154, 20);
            this.quantitytxt.TabIndex = 110;
            // 
            // typetxt
            // 
            this.typetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.typetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.typetxt.Location = new System.Drawing.Point(228, 89);
            this.typetxt.Name = "typetxt";
            this.typetxt.Size = new System.Drawing.Size(154, 20);
            this.typetxt.TabIndex = 109;
            // 
            // companytxt
            // 
            this.companytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.companytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.companytxt.Location = new System.Drawing.Point(228, 121);
            this.companytxt.Name = "companytxt";
            this.companytxt.Size = new System.Drawing.Size(154, 20);
            this.companytxt.TabIndex = 108;
            // 
            // warrantytxt
            // 
            this.warrantytxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.warrantytxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.warrantytxt.Location = new System.Drawing.Point(228, 322);
            this.warrantytxt.Name = "warrantytxt";
            this.warrantytxt.Size = new System.Drawing.Size(154, 20);
            this.warrantytxt.TabIndex = 107;
            // 
            // availtxt
            // 
            this.availtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.availtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.availtxt.Location = new System.Drawing.Point(228, 214);
            this.availtxt.Name = "availtxt";
            this.availtxt.Size = new System.Drawing.Size(154, 20);
            this.availtxt.TabIndex = 106;
            // 
            // domtxt
            // 
            this.domtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.domtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.domtxt.Location = new System.Drawing.Point(228, 249);
            this.domtxt.Name = "domtxt";
            this.domtxt.Size = new System.Drawing.Size(154, 20);
            this.domtxt.TabIndex = 105;
            // 
            // doetxt
            // 
            this.doetxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.doetxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doetxt.Location = new System.Drawing.Point(228, 282);
            this.doetxt.Name = "doetxt";
            this.doetxt.Size = new System.Drawing.Size(154, 20);
            this.doetxt.TabIndex = 104;
            // 
            // costtxt
            // 
            this.costtxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.costtxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.costtxt.Location = new System.Drawing.Point(228, 183);
            this.costtxt.Name = "costtxt";
            this.costtxt.Size = new System.Drawing.Size(154, 20);
            this.costtxt.TabIndex = 103;
            // 
            // coloroptxt
            // 
            this.coloroptxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.coloroptxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.coloroptxt.Location = new System.Drawing.Point(228, 147);
            this.coloroptxt.Name = "coloroptxt";
            this.coloroptxt.Size = new System.Drawing.Size(154, 20);
            this.coloroptxt.TabIndex = 102;
            // 
            // dimensiontxt
            // 
            this.dimensiontxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dimensiontxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dimensiontxt.Location = new System.Drawing.Point(625, 59);
            this.dimensiontxt.Name = "dimensiontxt";
            this.dimensiontxt.Size = new System.Drawing.Size(154, 20);
            this.dimensiontxt.TabIndex = 101;
            // 
            // nametxt
            // 
            this.nametxt.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.nametxt.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.nametxt.Location = new System.Drawing.Point(228, 57);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(154, 20);
            this.nametxt.TabIndex = 100;
            // 
            // warranty
            // 
            this.warranty.AutoSize = true;
            this.warranty.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.warranty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warranty.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.warranty.Location = new System.Drawing.Point(38, 322);
            this.warranty.Name = "warranty";
            this.warranty.Size = new System.Drawing.Size(174, 20);
            this.warranty.TabIndex = 99;
            this.warranty.Text = "Add Warranty (in years)";
            // 
            // dimensions
            // 
            this.dimensions.AutoSize = true;
            this.dimensions.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dimensions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dimensions.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dimensions.Location = new System.Drawing.Point(457, 59);
            this.dimensions.Name = "dimensions";
            this.dimensions.Size = new System.Drawing.Size(129, 20);
            this.dimensions.TabIndex = 98;
            this.dimensions.Text = "Add Dimensions:";
            // 
            // quantity
            // 
            this.quantity.AutoSize = true;
            this.quantity.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantity.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.quantity.Location = new System.Drawing.Point(457, 89);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(101, 20);
            this.quantity.TabIndex = 97;
            this.quantity.Text = "Add Quantity";
            // 
            // doe
            // 
            this.doe.AutoSize = true;
            this.doe.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.doe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doe.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.doe.Location = new System.Drawing.Point(38, 282);
            this.doe.Name = "doe";
            this.doe.Size = new System.Drawing.Size(129, 20);
            this.doe.TabIndex = 96;
            this.doe.Text = "Add Date Expire:";
            // 
            // type
            // 
            this.type.AutoSize = true;
            this.type.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.type.Location = new System.Drawing.Point(31, 87);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(88, 20);
            this.type.TabIndex = 95;
            this.type.Text = "Add Type  :";
            // 
            // company
            // 
            this.company.AutoSize = true;
            this.company.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.company.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.company.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.company.Location = new System.Drawing.Point(33, 121);
            this.company.Name = "company";
            this.company.Size = new System.Drawing.Size(117, 20);
            this.company.TabIndex = 94;
            this.company.Text = "Add Company :";
            // 
            // color
            // 
            this.color.AutoSize = true;
            this.color.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.color.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.color.Location = new System.Drawing.Point(34, 152);
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(146, 20);
            this.color.TabIndex = 93;
            this.color.Text = "Add Color Options :";
            // 
            // Cost
            // 
            this.Cost.AutoSize = true;
            this.Cost.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cost.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Cost.Location = new System.Drawing.Point(34, 183);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(83, 20);
            this.Cost.TabIndex = 92;
            this.Cost.Text = "Add Cost :";
            // 
            // availibility
            // 
            this.availibility.AutoSize = true;
            this.availibility.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.availibility.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.availibility.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.availibility.Location = new System.Drawing.Point(38, 214);
            this.availibility.Name = "availibility";
            this.availibility.Size = new System.Drawing.Size(116, 20);
            this.availibility.TabIndex = 91;
            this.availibility.Text = "Add Availibility :";
            // 
            // dom
            // 
            this.dom.AutoSize = true;
            this.dom.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dom.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.dom.Location = new System.Drawing.Point(38, 249);
            this.dom.Name = "dom";
            this.dom.Size = new System.Drawing.Size(191, 20);
            this.dom.TabIndex = 90;
            this.dom.Text = "Add Date of manufactire :";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.name.Location = new System.Drawing.Point(31, 54);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(90, 20);
            this.name.TabIndex = 89;
            this.name.Text = "Add name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(20, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 45);
            this.label1.TabIndex = 111;
            this.label1.Text = "Admin :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // addcosmetic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::businesssapp.Properties.Resources.cossss;
            this.ClientSize = new System.Drawing.Size(800, 353);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quantitytxt);
            this.Controls.Add(this.typetxt);
            this.Controls.Add(this.companytxt);
            this.Controls.Add(this.warrantytxt);
            this.Controls.Add(this.availtxt);
            this.Controls.Add(this.domtxt);
            this.Controls.Add(this.doetxt);
            this.Controls.Add(this.costtxt);
            this.Controls.Add(this.coloroptxt);
            this.Controls.Add(this.dimensiontxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.warranty);
            this.Controls.Add(this.dimensions);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.doe);
            this.Controls.Add(this.type);
            this.Controls.Add(this.company);
            this.Controls.Add(this.color);
            this.Controls.Add(this.Cost);
            this.Controls.Add(this.availibility);
            this.Controls.Add(this.dom);
            this.Controls.Add(this.name);
            this.Controls.Add(this.skintypetxt);
            this.Controls.Add(this.shadetxt);
            this.Controls.Add(this.packagetxt);
            this.Controls.Add(this.shade);
            this.Controls.Add(this.package);
            this.Controls.Add(this.skintype);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.add);
            this.Controls.Add(this.label5);
            this.Name = "addcosmetic";
            this.Text = "addcosmetic";
            this.Load += new System.EventHandler(this.addcosmetic_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.TextBox skintypetxt;
        private System.Windows.Forms.TextBox shadetxt;
        private System.Windows.Forms.TextBox packagetxt;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Label skintype;
        private System.Windows.Forms.Label package;
        private System.Windows.Forms.Label shade;
        private System.Windows.Forms.TextBox quantitytxt;
        private System.Windows.Forms.TextBox typetxt;
        private System.Windows.Forms.TextBox companytxt;
        private System.Windows.Forms.TextBox warrantytxt;
        private System.Windows.Forms.TextBox availtxt;
        private System.Windows.Forms.TextBox domtxt;
        private System.Windows.Forms.TextBox doetxt;
        private System.Windows.Forms.TextBox costtxt;
        private System.Windows.Forms.TextBox coloroptxt;
        private System.Windows.Forms.TextBox dimensiontxt;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label warranty;
        private System.Windows.Forms.Label dimensions;
        private System.Windows.Forms.Label quantity;
        private System.Windows.Forms.Label doe;
        private System.Windows.Forms.Label type;
        private System.Windows.Forms.Label company;
        private System.Windows.Forms.Label color;
        private System.Windows.Forms.Label Cost;
        private System.Windows.Forms.Label availibility;
        private System.Windows.Forms.Label dom;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label label1;
    }
}