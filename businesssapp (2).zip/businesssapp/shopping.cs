﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;



namespace businesssapp
{
    public partial class shopping : Form
    {
        public shopping()
        {
            InitializeComponent();
          
          
            InitializeProductListofelectronics();
            InitializeProductListofcosmetics();
            InitializeProductListofhomedecor();
        }
       
        public void InitializeProductListofelectronics()
        {

            List<products> electroniclist = objecthandler.getelectronic().showallproducts();
            foreach (electronics electronicitem in electroniclist)
            {
                ListViewItem item = new ListViewItem(electronicitem.getname());
                item.SubItems.Add(electronicitem.getcost().ToString()); 


                item.SubItems.Add(electronicitem.getcompany());
                item.SubItems.Add(string.Join(",", electronicitem.getcolor()));
                item.SubItems.Add(electronicitem.getType());
                item.SubItems.Add(electronicitem.getdateofmanufacture().ToShortDateString());
                item.SubItems.Add(electronicitem.getdateofexpire().ToShortDateString());
                item.SubItems.Add(electronicitem.getwarrantyDuration().ToString());
                item.SubItems.Add(string.Join(",", electronicitem.getdimensions())); 

               


                listView1.Items.Add(item);


            }
            electroniclist.Clear();
        }
        public void InitializeProductListofcosmetics()
        {

            List<products> cosmeticlist = objecthandler.getcosmetic().showallproducts();
            foreach (cosmetics cosmeticitem in cosmeticlist)
            {
                ListViewItem item = new ListViewItem(cosmeticitem.getname());
                item.SubItems.Add(cosmeticitem.getcost().ToString()); 


                item.SubItems.Add(cosmeticitem.getcompany());
                item.SubItems.Add(string.Join(",", cosmeticitem.getcolor()));
                item.SubItems.Add(cosmeticitem.getType());
                item.SubItems.Add(cosmeticitem.getdateofmanufacture().ToShortDateString());
                item.SubItems.Add(cosmeticitem.getdateofexpire().ToShortDateString());
                item.SubItems.Add(cosmeticitem.getwarrantyDuration().ToString());
                item.SubItems.Add(string.Join(",", cosmeticitem.getdimensions())); 
               

                listView1.Items.Add(item);


            }
            cosmeticlist.Clear();
        }

        public void InitializeProductListofhomedecor()
        {

            List<products> homedecorlist = objecthandler.gethomedecor().showallproducts();
            foreach (homeDecor homedecitem in homedecorlist)
            {
                ListViewItem item = new ListViewItem(homedecitem.getname());
                item.SubItems.Add(homedecitem.getcost().ToString()); 


                item.SubItems.Add(homedecitem.getcompany());
                item.SubItems.Add(string.Join(",", homedecitem.getcolor()));
                item.SubItems.Add(homedecitem.getType());
                item.SubItems.Add(homedecitem.getdateofmanufacture().ToShortDateString());
                item.SubItems.Add(homedecitem.getdateofexpire().ToShortDateString());
                item.SubItems.Add(homedecitem.getwarrantyDuration().ToString());
                item.SubItems.Add(string.Join(",", homedecitem.getdimensions())); 
               
                
                listView1.Items.Add(item);


            }
            homedecorlist.Clear();
        }


        private void shopping_Load(object sender, EventArgs e)
        {
           
        }


        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            businesssapp.customermenu cmenu = new businesssapp.customermenu();
            cmenu.ShowDialog();
        }



       





        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }




        private void btnSave_Click_1(object sender, EventArgs e)
        {
            // Separate selected items into respective categories
            SharedContext.ClearSelectedItems();

            foreach (ListViewItem item in listView1.SelectedItems)
            {
                if (item.SubItems[4].Text == "electronic") 
                {
                    SharedContext.AddBoughtelectronics(item);
                }
                else if (item.SubItems[4].Text == "cosmetic") 
                {
                    SharedContext.AddBoughtcosmetics(item);
                }
                else if (item.SubItems[4].Text == "homedecor") 
                {
                    SharedContext.AddBoughthomedecor(item);
                }
            }


            string username = SharedContext.Username;
            int id = objecthandler.getsignup().GetUserID(username);
           
            SharedContext.Userid = id;
            // Save selected items for each category
            foreach (ListViewItem selectedItem in SharedContext.getelectronics())
            {
                MessageBox.Show(selectedItem.SubItems[0].Text + "  Price : " + selectedItem.SubItems[1].Text + "  added to your cart (Electronic)");

                if (selectedItem.SubItems[4].Text == "electronic")
                {
                    objecthandler.getelectronic().SaveSelectedItems(SharedContext.getelectronics(), username, id);
                }
            }
            foreach (ListViewItem selectedItem in SharedContext.getcosmetics())
            {
                MessageBox.Show(selectedItem.SubItems[0].Text + "  Price : " + selectedItem.SubItems[1].Text + "  added to your cart (Cosmetic)");
                if (selectedItem.SubItems[4].Text == "cosmetic")
                {
                    objecthandler.getcosmetic().SaveSelectedItems(SharedContext.getcosmetics(), username, id);
                }
            }
      

            foreach (ListViewItem selectedItem in SharedContext.gethomedecor())
            {
                MessageBox.Show(selectedItem.SubItems[0].Text + "  Price : " + selectedItem.SubItems[1].Text + "  added to your cart (Home Decor)");
                if (selectedItem.SubItems[4].Text == "homedecor")
                {
                    objecthandler.gethomedecor().SaveSelectedItems(SharedContext.gethomedecor(), username, id);
                }
            }
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            businesssapp.cart carts = new businesssapp.cart();
            carts.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
    }

   

       
        


       
        
          