﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace businesssapp
{
    public partial class removeuser : Form
    {
        public removeuser()
        {
            InitializeComponent();
            Initializeallusers();
        }

        private void removeuser_Load(object sender, EventArgs e)
        {

        }
        private void Initializeallusers()
        {
            List<signupBL> userlist = objecthandler.getsignup().getall();

            foreach (signupBL homedecitem in userlist)
            {
                ListViewItem item = new ListViewItem(homedecitem.getid().ToString());
               
                item.SubItems.Add(homedecitem.getname().ToString());
              

                item.SubItems.Add(homedecitem.getpass().ToString());
                item.SubItems.Add(homedecitem.getroll().ToString());



                listView1.Items.Add(item);


            }
            userlist.Clear();
        }
        private static int id;
        private void setid(int userid)
        {



            id = userid;

        }
        private int getid()
        {
            return id;
        }
        private void DeleteSelectedRow()
        {
            if (listView1.SelectedItems.Count > 0)
            {
               
              
                
                 listView1.Items.Remove(listView1.SelectedItems[0]);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            exit();
        }
        private void exit()
        {
            this.Hide();
            adminmenu cos = new adminmenu();
            cos.ShowDialog();
        }
            private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
               
                string idretrieve = listView1.SelectedItems[0].SubItems[0].Text;
                int id = int.Parse(idretrieve);

               
                objecthandler.getsignup().DeleteUserById(id);

              
                DeleteSelectedRow();

              
                MessageBox.Show("Selected user deleted");

               
            }
            else
            {
                MessageBox.Show("Please select a user to delete.");
            }
        }
    }
}
