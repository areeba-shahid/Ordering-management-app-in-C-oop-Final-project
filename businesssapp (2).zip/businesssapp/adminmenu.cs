﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class adminmenu : Form
    {
        public adminmenu()
        {
            InitializeComponent();
           
        }
        private void setname()
        {
            label1.Text = SharedContext.Username;
        }
        private void Next_Click(object sender, EventArgs e)
        {
            this.Hide();
            addelectronic eg = new addelectronic();
            eg.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            addcosmetic eg = new addcosmetic();
            eg.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            addhomedecor eg = new addhomedecor();
            eg.ShowDialog();
        }

        private void adminmenu_Load(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            editelectronics edit = new editelectronics();
            edit.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            editcosmetics cos = new editcosmetics();
            cos.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            edithomedecor cos = new edithomedecor();
            cos.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            deleteelectronic cos = new deleteelectronic();
            cos.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            deletecosmetic cos = new deletecosmetic();
            cos.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            deletehomedecor cos = new deletehomedecor();
            cos.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            seeallproducts cos = new seeallproducts();
            cos.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            seeallToshipOrders cos = new seeallToshipOrders();
            cos.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            seeallreturneditems cos = new seeallreturneditems();
            cos.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            removeuser cos = new removeuser();
            cos.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            seeallusers cos = new seeallusers();
            cos.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            
        }

        private void button16_Click(object sender, EventArgs e)
        {
            this.Hide();
            login pay = new login();
            pay.ShowDialog();
        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            editcredentials pay = new editcredentials();
            pay.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.Hide();
            setdeliveryfee pay = new setdeliveryfee();
            pay.ShowDialog();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.Hide();
            setpaymentmethods pay = new setpaymentmethods();
            pay.ShowDialog();
        }
    }
}
