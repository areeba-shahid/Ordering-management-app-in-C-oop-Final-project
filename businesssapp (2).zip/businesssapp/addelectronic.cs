﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class addelectronic : Form
    {
        public addelectronic()
        {
            InitializeComponent();
          
        }
        bool buttonclick = false;
        private void setname()
        {
            label1.Text = SharedContext.Username;
        }
        private List<electronics> newelectronic = new List<electronics>();
        private void exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }
        private List<electronics> accessall()
        {
            string name = nametxt.Text; ;
            string type = typetxt.Text;
            string company = companytxt.Text;
            float cost = Convert.ToSingle(costtxt.Text);
            string[] color = coloroptxt.Text.Split(',');
            int availibility = Convert.ToInt32(availtxt.Text);
            DateTime dateofmanufacture = Convert.ToDateTime(domtxt.Text);
            DateTime dateofexpire = Convert.ToDateTime(doetxt.Text);
            float warranty = Convert.ToSingle(warrantytxt.Text);
            string[] dimensions = dimensiontxt.Text.Split(',');
            float quantity = Convert.ToSingle(quantitytxt.Text);
            string[] applications = apptxt.Text.Split(',');

            string[] operating = operatingtxt.Text.Split(',');

            string typeofelectronics = toetxt.Text;


            electronics elec = new electronics(name, type, company, color, cost, availibility, dateofmanufacture, dateofexpire, warranty, dimensions, quantity, typeofelectronics, applications, operating);

            newelectronic.Add(elec);
            return newelectronic;
        }
        private void addelectronic_Load(object sender, EventArgs e)
        {

        }
        private bool AreAllTextBoxesFilled()
        {
            foreach (Control control in Controls) 
            {
                if (control is System.Windows.Forms.TextBox textBox) 
                {
                    if (string.IsNullOrEmpty(textBox.Text)) 
                    {
                        return false; 
                    }
                }
            }
            return true; 
        }

        private void add_Click(object sender, EventArgs e)
        {
            List<electronics> topasslist = accessall();
            electronicDB elec = new electronicDB(objecthandler.conn);
            elec.storeindb(topasslist);
            buttonclick = true;
            bool textboxcondition = AreAllTextBoxesFilled();
            if (buttonclick && textboxcondition)
            {


            }
            else
            {
                MessageBox.Show("Fill out all information Correctly");
            }
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }

        private void availtxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
