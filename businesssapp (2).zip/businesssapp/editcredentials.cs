﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businesssapp
{
    public partial class editcredentials : Form
    {
        public editcredentials()
        {
            InitializeComponent();
            setname();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void namelabel_Click(object sender, EventArgs e)
        {

        }
        private void setname()
        {

            namelabel.Text = SharedContext.Username;
        }

        private void editcredentials_Load(object sender, EventArgs e)
        {

        }



        private void previouspassword_TextChanged(object sender, EventArgs e)
        {

        }

        private bool checkifitscorrect()
        {
            string previouspass;
            previouspass = previouspassword.Text;
            string username = SharedContext.Username;
            int id = objecthandler.getsignup().GetUserID(username);
            string passwordfromfunction = objecthandler.getsignup().RetrievePassword(username, id);
            if (previouspass == passwordfromfunction)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        private void decision()
        {
            bool check = checkifitscorrect();
            if (check == true)
            {
                MessageBox.Show("  Password verified ");
            }
            if (check == false)
            {
                MessageBox.Show("  Password is incorrect ");
                this.Hide();
                customermenu cus = new customermenu();
                cus.ShowDialog();
            }

        }
        private bool button2Clicked = false;

       

        private void button2_Click(object sender, EventArgs e)
        {
            button2Clicked = true;
            decision();
        }

        private void constraint()
        {
            if (button2Clicked == false)
            {
                MessageBox.Show("First click on  submit button  front of previous password");
            }
            else
            {

            }
        }

        private void newcredentialsbtn_Click(object sender, EventArgs e)
        {
            string username = SharedContext.Username;
            string previouspass = previouspassword.Text;
            int id = objecthandler.getsignup().GetUserID(username);
            string newname = newusername.Text;
            string newpass = newpassword.Text;
            bool usernamecheck = objecthandler.getsignup().IsusernameUnique(newname);
            bool passuniquecheck = objecthandler.getsignup().IsPasswordUnique(newpass);
            bool passpasswordvaliditycheck = objecthandler.getsignup().validityofpassword(newpass);


            if (usernamecheck == false || passuniquecheck == false || passpasswordvaliditycheck == false)
            {

                MessageBox.Show("Read instructions carefully . or change credentials as they may be already in use");


            }
            if (usernamecheck == true && passuniquecheck == true && passpasswordvaliditycheck == true)
            {

                objecthandler.getsignup().UpdateUsernameAndPassword(username, previouspass, newname, newpass);
                objecthandler.getcart().UpdateUsernameAndPassword(username,id,newname);
                objecthandler.getpayment().UpdateUsernameAndPassword(username, id, newname);
                MessageBox.Show("updated ");

               

                this.Hide();
                login cmenu = new login();
                cmenu.ShowDialog();

            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Password should be at least of 8 characters .u can use special characters and numbers as well . 1st character should be capital . Password of an user can not be assigned  to other user");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            login cmenu = new login();
            cmenu.ShowDialog();
        }
    }
}
