﻿using businessapplibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace businesssapp
{
    public partial class editelectronics : Form
    {
        public editelectronics()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;

        }
        DataTable dataTable = new DataTable();
        List<electronics> newelectronic = new List<electronics>();
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void editproducts_Load(object sender, EventArgs e)
        {
            dataTable.Columns.Add("Name", typeof(string));
            dataTable.Columns.Add("Company", typeof(string));

            dataTable.Columns.Add("Color", typeof(string));
            dataTable.Columns.Add("Cost", typeof(string));


            dataTable.Columns.Add("DateOfManufacture", typeof(DateTime));
            dataTable.Columns.Add("DateOfExpire", typeof(DateTime));

            dataTable.Columns.Add("WarrantyDuration", typeof(float));
            dataTable.Columns.Add("Dimensions", typeof(string));
            dataTable.Columns.Add("Quantity", typeof(string));


            dataTable.Columns.Add("TypeOfElectronic", typeof(string));
            dataTable.Columns.Add("Applications", typeof(string));

            dataTable.Columns.Add("OperatingConditions", typeof(string));


            dataGridView1.DataSource = dataTable;

            List<products> electronicsitems = objecthandler.getelectronic().showallproducts();
            foreach (electronics electronic in electronicsitems)
            {
                dataTable.Rows.Add(electronic.getname(), electronic.getcompany(), electronic.getcolor(), electronic.getcost(),
                    electronic.getdateofmanufacture(), electronic.getdateofexpire(), electronic.getwarrantyDuration(), electronic.getdimensions(),
       electronic.getquantity(),          electronic.gettypeofelectronic(), electronic.getapplications(), electronic.getoperatingconditions());

            }
            electronicsitems.Clear();
            dataGridView1.DataSource = dataTable;



        }

        private static int id;
        private void setid(string name, string company)
        {
            

            electronicDB el = new electronicDB(objecthandler.conn);
            id = el.retrieveid(name, company);
          
        }
        private int getid()
        {
            return id;
        }
      
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
           
            if (dataGridView1.SelectedRows.Count > 0)
            {
                
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

               
                string name = selectedRow.Cells["Name"].Value.ToString();
                string company = selectedRow.Cells["Company"].Value.ToString();
                string Color = selectedRow.Cells["Color"].Value.ToString();
                string cost = selectedRow.Cells["Cost"].Value.ToString();
                string dateofmanufacture = selectedRow.Cells["DateOfManufacture"].Value.ToString();
                string dateofexpire = selectedRow.Cells["DateOfExpire"].Value.ToString();
                string Warrantyduration = selectedRow.Cells["WarrantyDuration"].Value.ToString();
                string Dimensions = selectedRow.Cells["Dimensions"].Value.ToString();
                string quantity = selectedRow.Cells["Quantity"].Value.ToString(); ;
                string TypeOfElectronic = selectedRow.Cells["TypeOfElectronic"].Value.ToString();
                string Applications = selectedRow.Cells["Applications"].Value.ToString();
                string OperatingConditions = selectedRow.Cells["OperatingConditions"].Value.ToString();
                setid(name, company);


                
                nametxt.Text = name;
                companytxt.Text = company;
                coloroptxt.Text = Color;
                costtxt.Text = cost;
                domtxt.Text = dateofmanufacture;
                doetxt.Text = dateofexpire;

                warrantytxt.Text = Warrantyduration;
                dimensiontxt.Text = Dimensions;
                quantitytxt.Text = quantity;
                toetxt.Text = TypeOfElectronic;
                apptxt.Text = Applications;
                opeartingtxt.Text = OperatingConditions;

               
            }
            else
            {
                nametxt.Text = "";
                companytxt.Text = "";
                coloroptxt.Text = "";
                costtxt.Text = "";
                domtxt.Text = "";
                doetxt.Text = "";
                warrantytxt.Text = "";
                dimensiontxt.Text = "";
                quantitytxt.Text = "";
                toetxt.Text = "";
                apptxt.Text = "";
                opeartingtxt.Text = "";
            }

        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public List<electronics> retrieveupdatedvalues()
        {
            string name = nametxt.Text; ;
            string type ="";
            string company = companytxt.Text;
            float cost = Convert.ToSingle(costtxt.Text);
            string[] color = coloroptxt.Text.Split(',');
            int availibility= 0;
            DateTime dateofmanufacture = Convert.ToDateTime(domtxt.Text);
            DateTime dateofexpire = Convert.ToDateTime(doetxt.Text);
            float warranty = Convert.ToSingle(warrantytxt.Text);
            string[] dimensions = dimensiontxt.Text.Split(',');
            float quantity = Convert.ToSingle(quantitytxt.Text);
            string[] applications = apptxt.Text.Split(',');

            string[] operating = opeartingtxt.Text.Split(',');

            string typeofelectronics = toetxt.Text;


            electronics elec = new electronics(name, type, company, color, cost, availibility, dateofmanufacture, dateofexpire, warranty, dimensions, quantity, typeofelectronics, applications, operating);

            newelectronic.Add(elec);
            return newelectronic;
        }
        private void add_Click(object sender, EventArgs e)
        {

           
            List<electronics> topass=   retrieveupdatedvalues();
            electronicDB ele = new electronicDB(objecthandler.conn);
            ele.updateindb(topass,getid());
            exit();
        }
        private void exit()
        {
            this.Hide();
            adminmenu admin_menu = new adminmenu();
            admin_menu.ShowDialog();
        }

        private void bu_Click(object sender, EventArgs e)
        {
            exit();
        }
    }
}
