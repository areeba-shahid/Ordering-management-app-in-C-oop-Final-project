﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public interface IsignupDL
    {
        string GetRoll(string UserName, string UserPassword);
        signupBL storerespectively(string name, string password, string roll)
       ;
        string RetrievePassword(int id);
        void adduserintolist(signupBL user)
        ;
        List<signupBL> GetUsers()
       ;
        signupBL signin(signupBL user)
        ;
        bool validityofpassword(string password)
       ;
        bool IsPasswordUnique(string password)
       ;
        int GetUserID(string UserName);

        bool IsusernameUnique(string username);
        string RetrievePassword(string username, int id);
        List<signupBL> getall();
        void DeleteUserById(int id);
        void UpdateUsernameAndPassword(string previousUsername, string previousPassword, string newUsername, string newPassword);
    }
}

