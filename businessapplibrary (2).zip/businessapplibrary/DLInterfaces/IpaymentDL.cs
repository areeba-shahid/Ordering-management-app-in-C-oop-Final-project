﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public interface IpaymentDL
    {
        List<paymentBL> GetAllDataFromToShip();
        void UpdateUsernameAndPassword(string previousUsername, int id, string newUsername);
        List<paymentBL>  getalltoshipitem();
        void storepaymentrecord(string CustomerName, int CustomerId, float Price, string PaymentMethod, string itemsbought);
    }

}
