﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace businessapplibrary
{
    public interface IproductsDL
    {



        List<products> showallproducts();
        void SaveSelectedItems(List<ListViewItem> selectedItems,string username,int id);
        
    }
    }
