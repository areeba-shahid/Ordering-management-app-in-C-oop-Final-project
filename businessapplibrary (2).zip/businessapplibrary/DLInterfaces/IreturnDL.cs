﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
   public interface IreturnDL
    {


        List<ReturnItem> retrievedata(string username, int userid);
        void WriteReturnedItems(List<ReturnItem> items, int userid, string name);
       void RemoveProductFromBoughtItems(int itemId, string customerName);
        List<ReturnItem> PopulateListViewWithReturnedProducts(int id, string username);
        List<ReturnItem> retrieveall();
    }
}
