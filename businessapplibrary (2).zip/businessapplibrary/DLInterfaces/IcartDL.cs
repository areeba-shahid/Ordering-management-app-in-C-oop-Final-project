﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public interface IcartDL
    {
        void UpdateColor(int itemid, string selectedColor);
        List<CartItem> PopulateCart(string CustomerName, int id);
        void DeleteItemFromStorage(int itemId);
        void DeleteAllDataFromBoughtRecently();
        DataTable RetrieveDataFromBoughtRecently();
       void InsertDataIntoBought(DataTable dataTable);
        void UpdateUsernameAndPassword(string previousUsername, int id, string newUsername);
        
       
    }
}
