﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public class returnedProducts : products
    {

        public int ItemId { get; set; }
        public string CustomerName { get; set; }
        public int UserId { get; set; }
        public string ColorSelected { get; set; }

        public returnedProducts(int Itemid, string customerName, int userId, string colorSelected, string name, string Type, string company, string[] color, float cost) : base(name, Type, company, color, cost)
       
        {
            ItemId = Itemid;
            CustomerName = customerName;
            UserId = userId;
            ColorSelected = colorSelected;
        }

    }
}
