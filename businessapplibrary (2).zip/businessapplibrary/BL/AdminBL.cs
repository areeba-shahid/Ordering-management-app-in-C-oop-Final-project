﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public  class AdminBL : signupBL
    {
        public AdminBL(string username, string password) : base(username, password)
        {
            
        }


    }
}
