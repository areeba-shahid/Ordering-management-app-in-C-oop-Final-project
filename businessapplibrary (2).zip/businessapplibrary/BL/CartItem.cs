﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace businessapplibrary
{
    public class CartItem
    {

        public int itemid { get; set; }
        public string Name { get; set; }
        public float Price { get; set; }
        public bool HasColorOptions { get; set; }
        public List<string> AvailableColors { get; set; }
        public string SelectedColor { get; set; }

        public CartItem(int itemId, string name, float price, bool hasColorOptions, List<string> availableColors)
        {
            itemid = itemId;
            Name = name;
            Price = price;
            HasColorOptions = hasColorOptions;
            AvailableColors = availableColors;
            SelectedColor = "";
        }
        public CartItem(int itemId, string name, float price, string selectedcolor)
        {
            itemid = itemId;
            Name = name;
            Price = price;

            SelectedColor = selectedcolor;
        }
        public CartItem()
        {
        }
    }
}
