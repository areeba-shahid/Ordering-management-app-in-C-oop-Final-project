﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace businessapplibrary
{
    public class ReturnItem : products
    {//itemid, name, Color, Cost ,Company ,Type

        public int ItemId { get; set; }
      
        public string Color { get; set; }
        public string customername { get; set; }
        public int customerid { get; set; }
        public ReturnItem()
        {

        }
public ReturnItem(int itemid,string name, string color, float cost , string company , string type): base(name,type,company,cost)
        {
            ItemId = itemid;
           
            Color = color;
          

        }

        public ReturnItem(int itemid,int userid,string Customername, string name, string color, float cost, string company, string type) : base(name, type, company, cost)
        {
            customerid = userid;
            customername = Customername;
            ItemId = itemid;

            Color = color;


        }

    }
}
