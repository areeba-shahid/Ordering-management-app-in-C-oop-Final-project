﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
   public class cosmetics : products
    {
       
        private string skintype;
        private string shade;
       private string packagingtype;


        public cosmetics( string name, string Type, string company, string[] color, float cost, int availability,
            DateTime dateofmanufacture, DateTime dateofexpire, float warrantyDuration, 
            string[] dimensions, float quantity, string skintype, string shade, string packagingtype) : base( name,Type, company, color, cost, availability, dateofmanufacture, dateofexpire, warrantyDuration, dimensions, quantity)
        {
            this.packagingtype = packagingtype;
            this.shade = shade;
            this.skintype = skintype;


        }
        public string getskintype()
        {
            return skintype;
        }

        public void setskintype(string skintype)
        {
            this.skintype = skintype;
        }
        public string getPackagingtype()
        {
            return packagingtype;
        }

        public void setPackagingtype(string Packagingtype)
        {
            this.packagingtype = Packagingtype;
        }
        public string getshade()
        {
            return shade;
        }

        public void setshade(string shade)
        {
            this.shade = shade;
        }
    }
}
