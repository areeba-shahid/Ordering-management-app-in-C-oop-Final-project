﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public class paymentBL
    {

        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public int CustomerId { get; set; }
        public List<string> Items { get; set; }
        public float Price { get; set; }
        public string PaymentMethod { get; set; }
        public paymentBL(int orderid,string Customername,int customerid, List<string> items ,float price,string method)
        {
            OrderId = orderid;
            CustomerName = Customername;
            CustomerId = customerid;
            Items = items;
            Price = price;
            PaymentMethod = method;

        }

    }
}
