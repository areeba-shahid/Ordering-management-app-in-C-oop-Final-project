﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace businessapplibrary
{
    public class confirmedOrderBL
    {
       
        // aggregation with customerBL
        // has a relationship
        public int itemId { get; set; }
        public string ItemName { get; set; }
        

        public float Priceofitem { get; set; }
        public string SelectedColor { get; set; }
        public string buyernname { get; set; }
        public int buyerid { get; set; }

       
        public confirmedOrderBL(int itemid, string name, float price, string color,string username,int id)
        {
            itemId = itemid;
            ItemName = name;
           
            Priceofitem = price;
            SelectedColor = color;
            buyernname = username;
            buyerid = id;
        }
        public confirmedOrderBL()
        {

        }
       

        public void AddCartItemsToConfirmedOrder(List<CartItem> cartItems,string username,int userid)
        {
            foreach (CartItem item in cartItems)
            {
                // Retrieve data from the CartItem object
                int itemId = item.itemid;
                string name = item.Name;
                float price = item.Price;
                string color = item.SelectedColor;

            
                confirmedOrderBL orderItem = new confirmedOrderBL(itemId, name, price, color,username,userid);


                CustomerBL customer = new CustomerBL();

              
                customer.AddItemToConfirmedOrder(orderItem);
            }
        }


    }
}
