﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{

   
    // aggregation with confirmedorderBL
    public class CustomerBL : signupBL
    {
        private static float bill;
        public  List<confirmedOrderBL> Orders { get; private set; }

        public CustomerBL(string username, string password) : base(username, password)
        {
 
        }
       // aggregation
        public CustomerBL()
        {
            Orders = new List<confirmedOrderBL>();

        }
       
        public  void AddItemToConfirmedOrder(confirmedOrderBL order)
        {
            // Add the item to the confirmed order list
            Orders.Add(order);
        }
        public float CalculateTotalPrice(List<confirmedOrderBL> Orders)
        {
            float totalPrice = 0;

            foreach (confirmedOrderBL order in Orders)
            {
                totalPrice += order.Priceofitem;
            }
          
            return totalPrice;
            
        }
        public static void SetBill(float price)
        {
            bill = price;
        }
        public static float GetBill()
        {
            return bill;
        }
    }
}

