﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace businessapplibrary
{  
    public class electronics : products
    {
   
        
       private string typeofelectronic ;
        private string[] applications;
        private string[] OperatingConditions;
        public electronics( string name, string Type, string company, string[] color, float cost,int availibility, DateTime dateofmanufacture, DateTime dateofexpire,
            float warrantyDuration, string[] dimensions,float quantity, string typeofelectronic, string[] applications, string[] operatingconditions) :base ( name, Type, company,  color,  cost,  availibility,  dateofmanufacture,  dateofexpire,  warrantyDuration, dimensions, quantity) 
        {
         
            this.typeofelectronic = typeofelectronic;
           
            this.applications =  applications ;
            this.OperatingConditions = operatingconditions;


        }
      
        public string gettypeofelectronic()
        {
            return typeofelectronic;
        }
      
        public string getapplications()
        {
            return string.Join(", ", applications);
        }
        public string getoperatingconditions()
        {
            return string.Join(", ", OperatingConditions);
        }



        public void settypeofelectronic(string typeofelectronic)
        {
            this.typeofelectronic = typeofelectronic;
        }
        
        public void setapplications(string[] applications)
        {
            this.applications = applications;
        }
        public void setoperatingconditions(string[] operatingconditions)
        {
            this.OperatingConditions = operatingconditions;
        }

    }
  

}
