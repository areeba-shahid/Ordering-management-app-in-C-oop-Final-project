﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public class signupBL
    {
        protected int id;
        protected string username;
        protected string password;
        protected string roll;
        List<CustomerBL> customerslist;
        List<AdminBL> adminlist;

        //       composition
        public signupBL()
        {
            customerslist = new List<CustomerBL>();
            adminlist = new List<AdminBL>();
        }
        public signupBL(string username, string password, string roll)
        {
            this.username = username;
            this.password = password;
            this.roll = roll;

        }
        public signupBL( int id,string username, string password, string roll)
        {
            this.username = username;
            this.password = password;
            this.roll = roll;
            this.id = id;

        }

        public signupBL(string username, string password)
        {
            this.username = username;
            this.password = password;
            this.roll = "NA";

        }

        public string getname()
        {
            return username;
        }
        public string getpass()
        {
            return password;
        }
        public string getroll()
        {
            return roll;
        }
        public int getid()
        {
            return id;
        }
        public void setname(string name)
        {
            this.username = name;
        }
        public void setpass(string password)
        {
           this.password = password;
        }
        public void setroll(string roll)
        {
            this.roll=roll;
        }
        



    }
}
