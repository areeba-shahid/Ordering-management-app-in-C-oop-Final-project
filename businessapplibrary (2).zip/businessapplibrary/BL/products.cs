﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace businessapplibrary
{
    public class products
    {

        protected string name;
        protected string Type;
        protected string company;
        protected string[] color;
        protected float cost;
        protected int availibility;
        protected DateTime dateofmanufacture;
        protected DateTime dateofexpire;
        protected float warrantyDuration;
        protected string[] dimensions = new string[2];
        protected float quantity;
        public products(){}
        public products(string name,string type,string company,float Cost)
        {
            this.name = name;
            this.company = company;
            this.cost = Cost;
            this.Type = type;
        }
        public products(string name, string Type, string company, string[] color, float cost, int availibility, DateTime dateofmanufacture, DateTime dateofexpire, float warrantyDuration, string[] dimensions, float quantity)
        {
            this.name = name;
            this.company = company;
            this.color = color;
            this.cost = cost;
            this.Type = Type;
            this.availibility = availibility;
            this.dateofmanufacture = dateofmanufacture;
            this.dateofexpire = dateofexpire;
            this.warrantyDuration = warrantyDuration;
            this.dimensions = dimensions;
            this.quantity = quantity;
        }
        public products(string name, string Type, string company, string[] color, float cost)
        {
            this.name = name;
            this.company = company;
            this.color = color;
            this.cost = cost;
            this.Type = Type;
        }
        public string getname()
        {
            return name;
        }
        public string getcompany()
        {
            return company;
        }
        public float getquantity()
        {
            return quantity;
        }
        public string getcolor()
        {
            return string.Join(", ", color);
        }
        public string getdimensions()
        {
            return string.Join(", ", dimensions);
        }
        public string getType()
        {
            return Type;
        }
        public float getcost()
        {
            return cost;
        }
        public int getavailibility()
        {
            return availibility;
        }
        public DateTime getdateofmanufacture()
        {
            return dateofmanufacture;
        }
        public DateTime getdateofexpire()
        {
            return dateofexpire;
        }
        public float getwarrantyDuration()
        {
            return warrantyDuration;
        }
        public void setname(string name)
        {
            this.name = name;
        }
        public void setcompany(string company)
        {
            this.company = company;
        }
        public void settype(string Type)
        {
            this.Type = Type;
        }
        public void setcolor(string[] color)
        {
            this.color = color;
        }
        public void setcost(float cost)
        {
            this.cost = cost;
        }
        public void setquantity(float quantity)
        {
            this.quantity = quantity;
        }
        public void setavailability(int availibility)
        {
            this.availibility = availibility;
        }
        public void setdateofmanufacture(DateTime dateofmanufacture)
        {
            this.dateofmanufacture = dateofmanufacture;
        }
        public void setdateofexpire(DateTime dateofexpire)
        {
            this.dateofexpire = dateofexpire;
        }
        public void setwarrantyDuration(float warrantyDuration)
        {
            this.warrantyDuration = warrantyDuration;
        }

       
        public void setdimensions(string[] dimensions)
        {
            this.dimensions = dimensions;
        }
    }
}
