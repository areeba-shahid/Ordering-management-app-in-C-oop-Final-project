﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
   
   public class homeDecor :products
    {
        private string material;


        public homeDecor( string name, string Type, string company, string[] color, float cost, int availability, DateTime dateofmanufacture, DateTime dateofexpire, float warrantyDuration, string[] dimensions,float quantity, string material) : base(name,Type, company, color, cost, availability, dateofmanufacture, dateofexpire, warrantyDuration, dimensions, quantity)
        {

            this.material = material;

        }
        public string getmaterial()
        {
            return material;
        }
            public void setmaterial(string material)
            {
                this.material = material;
            }


        }
}
