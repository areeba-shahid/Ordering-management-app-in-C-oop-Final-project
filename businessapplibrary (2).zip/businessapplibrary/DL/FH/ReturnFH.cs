﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businessapplibrary
{
    public class ReturnFH : IreturnDL
    {
        string filePath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\boughtitems.txt";
     List<ReturnItem> items  = new List<ReturnItem>();
        public List<ReturnItem> retrievedata(string username, int userid)
        {
            
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length >= 6 && parts[1] == username && int.Parse(parts[2]) == userid) // Ensure the line has at least 6 parts
                        {
                            // Parse the parts and create a ReturnItem object
                            ReturnItem item = new ReturnItem();
                            item.ItemId = int.Parse(parts[0]);
                            item.setname(parts[3]);
                            item.setcost(float.Parse(parts[4]));
                            item.setcompany(parts[5]) ;
                            item.Color = parts[6];
                            item.settype(parts[7])  ;
                            items.Add(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading the file: " + ex.Message);
            }
           
         
            return items;

        }
         string filepath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\returnedItems.txt";
        public void WriteReturnedItems(List<ReturnItem> items,int userid,string name)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filepath, true))
                {
                    foreach (ReturnItem item in items)
                    {
                      
                       writer.WriteLine($"{item.ItemId},{name},{userid},{item.getname()},{item.getcost()},{item.getcompany()},{item.Color},{item.getType()}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while writing to the file: " + ex.Message);
            }
        }

        public void RemoveProductFromBoughtItems(int itemId, string customerName)
        {


            string file = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\boughtitems.txt";
            try
            {
            
                string[] lines = File.ReadAllLines(file);

               
                var updatedLines = new List<string>();

               
                foreach (string line in lines)
                {
                  
                    string[] parts = line.Split(',');

                   
                    if (parts.Length >= 2 && parts[0] == itemId.ToString() && parts[1] == customerName)
                    {
                        
                        continue;
                    }

                    
                    updatedLines.Add(line);
                }

              
                File.WriteAllLines(file, updatedLines);
            }
            catch (Exception ex)
            {
               MessageBox.Show("An error occurred while removing from file: " + ex.Message);
            }
        }
        public List<ReturnItem> PopulateListViewWithReturnedProducts(int id, string username)
        {
            string file = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\returnedItems.txt";
            try
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length >= 6 && parts[1] == username && int.Parse(parts[2]) == id) // Ensure the line has at least 6 parts
                        {
                            // Parse the parts and create a ReturnItem object
                            ReturnItem item = new ReturnItem();
                            item.ItemId = int.Parse(parts[0]);
                            item.setname(parts[3]);
                            item.setcost(float.Parse(parts[4]));
                            item.setcompany(parts[5]);
                            item.Color = parts[6];
                            item.settype(parts[7]);
                            items.Add(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading the file: " + ex.Message);
            }


            return items;


        }
        public List<ReturnItem> retrieveall()
        {
            return null;
        }
    }
}
    

