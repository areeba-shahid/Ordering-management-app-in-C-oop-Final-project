﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace businessapplibrary
{
  public class paymentFH : IpaymentDL
    {
        List<paymentBL> paymentrecords = new List<paymentBL>();
        string filepath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\ToShip.txt";
        public void storepaymentrecord(string CustomerName, int CustomerId, float Price, string PaymentMethod, string itemsbought)
        {
            
           

            try
            {
               
                using (StreamWriter writer = File.AppendText(filepath))
                {
                    int orderid = GenerateOrderId();
                    string itemsFormatted = itemsbought.Replace(",", ";");
                    string paymentRecord = $"{orderid},{CustomerName},{CustomerId},{itemsFormatted},{Price},{PaymentMethod}";

                    
                    writer.WriteLine(paymentRecord);
                }

                GetAllDataFromToShip();
            }
            catch (Exception ex)
            {
                
                Console.WriteLine("Error storing payment record: " + ex.Message);
            }
        }

        public int GenerateOrderId()
        {
            int orderId = 1; 

            try
            {
               
                if (File.Exists(filepath))
                {
                   
                    string lastOrderId = File.ReadLines(filepath).LastOrDefault();

                    if (!string.IsNullOrEmpty(lastOrderId))
                    {
                       
                        orderId = int.Parse(lastOrderId) + 1;
                    }
                }
            }
            catch (Exception ex)
            {
               
                Console.WriteLine("Error generating order ID: " + ex.Message);
            }

            return orderId;
        }
        public List<paymentBL> GetAllDataFromToShip()
        {
            

            try
            {
               

                
                if (File.Exists(filepath))
                {
                   
                    string[] lines = File.ReadAllLines(filepath);

                    foreach (string line in lines)
                    {
                       
                        string[] parts = line.Split(',');

                        int orderId = int.Parse(parts[0]);
                        string customerName = parts[1];
                        int customerId = int.Parse(parts[2]);
                        List<string> itemsList = parts[3].Split(',').ToList();
                        float price = float.Parse(parts[4]);
                        string paymentMethod = parts[5];

                      
                        paymentBL payment = new paymentBL(orderId, customerName, customerId, itemsList, price, paymentMethod);
                        paymentrecords.Add(payment);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error retrieving data from ToShip: " + ex.Message);
            }

            return paymentrecords;
        }
        public void UpdateUsernameAndPassword(string previousUsername, int id, string newUsername)
        {
            string filePathFortoship = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\ToShip.txt";
            try
            {
               
                string[] lines = File.ReadAllLines(filePathFortoship);

               
                bool updated = false;

               
                for (int i = 0; i < lines.Length; i++)
                {
                 
                    string[] fields = lines[i].Split(',');

                   
                    if (fields.Length >= 3 && fields[1] == previousUsername && int.Parse(fields[2]) == id)
                    {
                       
                        fields[1] = newUsername;

                        
                        lines[i] = string.Join(",", fields);

                       
                        updated = true;

                        
                        break;
                    }
                }

               
                if (updated)
                {
                    File.WriteAllLines(filePathFortoship, lines);
                    Console.WriteLine("Username updated successfully.");
                }
                else
                {
                    Console.WriteLine("No matching credentials found in the file.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while updating the file: " + ex.Message);
            }
        }
        public List<paymentBL> getalltoshipitem()
        {
            return paymentrecords;
        }
    }
}
