﻿

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace businessapplibrary
{
    public class signupFH : IsignupDL
    {
        private static string filePath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\signuprecords.txt";
        private static List<signupBL> userslistforfile = new List<signupBL>();
        public void adduserintolist(signupBL user)
        {
            userslistforfile.Add(user);

        }
        public string RetrievePassword(int id)
        {
            return null;
        }

        public bool validityofpassword(string password)
        {
            if (string.IsNullOrEmpty(password) || password.Length < 8)
            {
                return false;
            }

        
            else if (!char.IsUpper(password[0]))
            {
                return false;
            }
            else
            {
                return true;
            }

        }
        public signupBL storerespectively(string name, string pass, string roll)
        {


            int newUserId;
            if (userslistforfile.Count > 0)
            {
                newUserId = userslistforfile[userslistforfile.Count - 1].getid() + 1;
            }
            else
            {
                newUserId = 1;
            }

           
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
               
                writer.WriteLine($"{newUserId},{name},{pass},{roll}");
                writer.Flush();
                writer.Close();
            }

            signupBL user = new signupBL(newUserId, name, pass, roll);
            adduserintolist(user);
            return user;
        }



        public bool IsPasswordUnique(string password)
        {

            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"File {filePath} not found.");
            }

           
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                   
                    string[] parts = line.Split(',');
                    foreach (string part in parts)
                    {
                       

                        if (parts.Length == 4 && parts[2] == password)
                        {
                            return false; 
                        }
                    }
                }
                return true; 
            }
        }
        public bool IsusernameUnique(string username)
        {

            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"File {filePath} not found.");
            }

        
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                 
                    string[] parts = line.Split(',');
                    foreach (string part in parts)
                    {
                     

                        if (parts.Length == 4 && parts[1] == username)
                        {
                            return false; 
                        }
                    } 
                }
                return true;
            }
        }
        public string GetRoll(string username, string password)
            {
                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException($"File {filePath} not found.");
                }

                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        // Split the line into username, password, and roll
                        string[] parts = line.Split(',');
                        if (parts.Length == 4 && parts[1] == username && parts[2] == password)
                        {
                            return parts[3];
                        }
                    }
                }

                return null; 

            
        }
        public signupBL signin(signupBL user)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"File {filePath} not found.");
            }

          
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                
                    string[] parts = line.Split(',');
                    if (parts.Length == 4 && parts[1] == user.getname() && parts[2] == user.getpass())
                    {
                        int id = Convert.ToInt32(parts[0]);
                       
                        return new signupBL(id, parts[1], parts[2], parts[3]);
                    }
                }
            }

            return null; // Return null 

        }
        public List<signupBL> GetUsers()
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"File {filePath} not found.");
            }

           
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                 
                    string[] parts = line.Split(',');
                    if (parts.Length == 4)
                    {
                        int id = Convert.ToInt32(parts[0]);
                        signupBL user = new signupBL(id, parts[1], parts[2], parts[3]);
                        adduserintolist(user);
                    }
                }
            }

            return userslistforfile;
        }

        public int GetUserID(string UserName)
        {
            int UserID = -1;

           
            if (!string.IsNullOrEmpty(UserName))
            {
             
                string[] lines = File.ReadAllLines(filePath);

             
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 4 && parts[1].Trim() == UserName.Trim())
                    {
                      
                        if (int.TryParse(parts[0], out UserID))
                        {
                            return UserID;
                        }
                        else
                        {
                            
                            Console.WriteLine("Error: Unable to parse UserID from file.");
                        }
                    }
                }
            }

            return UserID;
        }

        public string RetrievePassword(string username, int id)
        {
            string password = null; 

            try
            {
                
                string filePath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\signuprecords.txt";

               
                string[] lines = File.ReadAllLines(filePath);

              
                foreach (string line in lines)
                {
                   
                    string[] fields = line.Split(',');

                    
                    if (fields.Length == 4)
                    {
                       
                        int fileID = int.Parse(fields[0]);
                        string fileUsername = fields[1];
                        string filePassword = fields[2];
                        string fileRoll = fields[3];

                       
                        if (fileID == id && fileUsername == username)
                        {
                           
                            password = filePassword;
                            break; 
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                
                Console.WriteLine("An error occurred while reading the file: " + ex.Message);
            }

          
            return password;
        }
        public void UpdateUsernameAndPassword(string previousUsername, string previousPassword, string newUsername, string newPassword)
        {
            string filePaths = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\signuprecords.txt";

            try
            {
                
                string[] lines = File.ReadAllLines(filePaths);

              
                bool updated = false;

              
                for (int i = 0; i < lines.Length; i++)
                {
                   
                    string[] fields = lines[i].Split(',');

                   
                    if (fields.Length >= 3 && fields[1] == previousUsername && fields[2] == previousPassword)
                    {
                       
                        fields[1] = newUsername;
                        fields[2] = newPassword;

                        
                        lines[i] = string.Join(",", fields);

                     
                        updated = true;

                 
                        break;
                    }
                }

         
                if (updated)
                {
                    File.WriteAllLines(filePath, lines);
                    Console.WriteLine("Username and password updated successfully.");
                }
                else
                {
                    Console.WriteLine("No matching credentials found in the file.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while updating the file: " + ex.Message);
            }
        }
public List<signupBL> getall()
        {
            return null;
        }
        public void DeleteUserById(int id)
        {

        }
    }

}
    
