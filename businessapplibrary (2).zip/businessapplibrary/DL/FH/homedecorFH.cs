﻿

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace businessapplibrary
{
    public class homedecorFH : IproductsDL
    {


        private static string filepath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\decoritemsrecord.txt";
        List<products> hdecorlist = new List<products>();
        public List<products> showallproducts()
        {

            try
            {
                using (StreamReader reader = new StreamReader(filepath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] data = line.Split(',');

                        string name = data[0];
                        string type = data[1];
                        string company = data[2];
                        string[] color = data[3].Split(';');
                        float cost = float.Parse(data[4]);
                        int availibility = int.Parse(data[5]);
                        DateTime dateOfManufacture = DateTime.Parse(data[6]);
                        DateTime dateOfExpire = DateTime.Parse(data[7]);
                        float warrantyDuration = float.Parse(data[8]);
                        string[] dimensions = data[9].Split(';');
                        float quantity = float.Parse(data[10]);
                        string material = data[11];

                        homeDecor homedec = new homeDecor(name, type, company, color, cost, availibility, dateOfManufacture, dateOfExpire, warrantyDuration, dimensions, quantity, material);

                        hdecorlist.Add(homedec);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            return hdecorlist;
        }
        string filepathofboughtrecently = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\boughtrecently.txt";

        public void SaveSelectedItems(List<ListViewItem> selectedItems, string username, int id)
        {
         
           
            int nextItemId = GetNextItemId();

           
            using (StreamWriter writer = new StreamWriter(filepathofboughtrecently, true))
            {
                foreach (ListViewItem item in selectedItems)
                {
                    List<string> formattedSubItems = new List<string>();
                    for (int i = 0; i < item.SubItems.Count; i++)
                    {
                        string subItemText = item.SubItems[i].Text.Trim();

                        
                        if (i == 3 || i == 8)
                        {
                            subItemText = string.Join(";", subItemText.Split(',').Select(s => s.Trim()));
                        }

                        formattedSubItems.Add(subItemText);
                    }

                  
                    string line = $"{nextItemId},{username},{id},{string.Join(",", formattedSubItems)}";

                   
                    writer.WriteLine(line);

                  
                    nextItemId++;
                }
            }
        }

      
    
        private int GetNextItemId()
        {
            
            if (File.Exists(filepathofboughtrecently))
            {
               
                using (StreamReader reader = new StreamReader(filepathofboughtrecently))
                {
                    int lastItemId = 0;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length > 0 && int.TryParse(parts[0], out int itemId))
                        {
                            lastItemId = Math.Max(lastItemId, itemId);
                        }
                    }
                   
                    return lastItemId + 1;
                }
            }
            else
            {
              
                return 1;
            }
        }




    }


}


