﻿

using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace businessapplibrary
{
    public class cartFH : IcartDL
    {

        public List<CartItem> Items { get; private set; }


        public cartFH()
        {
            Items = new List<CartItem>();
        }
        private static string filepath = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\boughtrecently.txt";



        public List<CartItem> PopulateCart(string CustomerName, int id)
        {
            List<CartItem> items = new List<CartItem>();

          
            using (StreamReader reader = new StreamReader(filepath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    
                    string[] parts = line.Split(',');

                  
                    if (parts.Length >= 7)
                    {
                       
                        if (parts[1].Trim() == CustomerName && parts[2].Trim() == id.ToString())
                        {
                            int itemId = int.Parse(parts[0]);

                          
                            string itemName = parts[3];
                            string costString = parts[4].Trim(); // Remove any leading or trailing whitespace




                           
                            float itemPrice = float.Parse(costString);

                            
                            List<string> colorOptions = new List<string>();
                            string colorOptionsString = parts[6]; // Adjust index for color options
                            colorOptions = colorOptionsString.Split(';').ToList();

                           
                            bool hasColorOptions = colorOptions.Count > 1;

                          
                            CartItem item = new CartItem(itemId, itemName, itemPrice, hasColorOptions, colorOptions);
                            items.Add(item);
                        }
                    }

                }
            }

            return items;
        }

        public void UpdateColor(int itemid, string selectedColor)
        {

           
            string[] lines = File.ReadAllLines(filepath);

            
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] parts = line.Split(',');


                if (parts.Length > 2 && parts[0].Trim() == itemid.ToString())
                {
                    
                    parts[6] = selectedColor;

                    
                    lines[i] = string.Join(",", parts);
                    break; 
                }
            }

            File.WriteAllLines(filepath, lines);
        }

        public void DeleteItemFromStorage(int itemId)
        {


            try
            {
                
                string[] lines = File.ReadAllLines(filepath);

               
                using (StreamWriter writer = new StreamWriter(filepath))
                {
                    foreach (string line in lines)
                    {
                      
                        string[] parts = line.Split(',');

                       
                        if (parts.Length > 0 && parts[0].Trim() != itemId.ToString())
                        {
                          
                            writer.WriteLine(line);
                        }
                    }
                }

              
                Console.WriteLine("Item with ID " + itemId + " deleted from storage.");
            }
            catch (IOException ex)
            {

                Console.WriteLine("Error deleting item from storage: " + ex.Message);
            }
            catch (Exception ex)
            {
              
                Console.WriteLine("Error deleting item from storage: " + ex.Message);
            }


        }
        public void DeleteAllDataFromBoughtRecently()
        {
            try
            {
               
                using (StreamWriter writer = new StreamWriter(filepath, false))
                {
                    
                }
                Console.WriteLine("All data deleted from boughtrecently.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while deleting data from boughtrecently: " + ex.Message);
            }
        }
        public DataTable RetrieveDataFromBoughtRecently()
        {
            DataTable dataTable = new DataTable();

            try
            {
                using (StreamReader reader = new StreamReader(filepath))
                {
                    
                    string firstLine = reader.ReadLine();
                    if (firstLine == null)
                    {
                        MessageBox.Show("The file is empty.");
                        return dataTable;
                    }

                    string[] columnNames = firstLine.Split(',');

                   
                    for (int i = 0; i < columnNames.Length; i++)
                    {
                        // Ensure the column name is unique
                        string columnName = "Column" + (i + 1);
                        while (dataTable.Columns.Contains(columnName))
                        {
                            columnName += "_"; 
                        }
                        dataTable.Columns.Add(columnName.Trim()); 
                    }


                    reader.BaseStream.Seek(0, SeekOrigin.Begin);

                    
                    string line;
                    bool firstLineSkipped = false;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!firstLineSkipped)
                        {
                            firstLineSkipped = true;
                            continue; 
                        }

                        string[] values = line.Split(',');
                        dataTable.Rows.Add(values);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading the file: " + ex.Message);
            }

            return dataTable;
        }

        public void InsertDataIntoBought(DataTable dataTable)
        {
            string filePathForBought = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\boughtitems.txt";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePathForBought, true))
                {
                    foreach (DataRow row in dataTable.Rows)
                    {
                        string[] fields = new string[dataTable.Columns.Count];
                        for (int i = 0; i < dataTable.Columns.Count; i++)
                        {
                            fields[i] = row[i].ToString();
                        }
                        string line = string.Join(",", fields);
                        writer.WriteLine(line);
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while writing to the file: " + ex.Message);
            }
        }
       public void UpdateUsernameAndPassword(string previousUsername, int id, string newUsername)
        {
            string filePathForBought = "C:\\Users\\Rashid ch\\OneDrive\\Documents\\boughtitems.txt";
            try
            {
               
                string[] lines = File.ReadAllLines(filePathForBought);

               
                bool updated = false;

               
                for (int i = 0; i < lines.Length; i++)
                {
                    
                    string[] fields = lines[i].Split(',');

                   
                    if (fields.Length >= 3 && fields[1] == previousUsername && int.Parse(fields[2]) == id)
                    {
                       
                        fields[1] = newUsername;

                      
                        lines[i] = string.Join(",", fields);

                       
                        updated = true;

                     
                        break;
                    }
                }

               
                if (updated)
                {
                    File.WriteAllLines(filePathForBought, lines);
                    Console.WriteLine("Username updated successfully.");
                }
                else
                {
                    Console.WriteLine("No matching credentials found in the file.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while updating the file: " + ex.Message);
            }
        }
    }

}

