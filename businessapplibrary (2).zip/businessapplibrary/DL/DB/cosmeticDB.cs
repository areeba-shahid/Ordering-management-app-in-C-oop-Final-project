﻿

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace businessapplibrary
{
    public class cosmeticDB : IproductsDL
    {
        string connection = "";

        static cosmeticDB instance;

        List<products> cosmeticslist;
        public cosmeticDB(string connection)
        {
            this.connection = connection;
            cosmeticslist = new List<products>();
        }
        public static cosmeticDB getInstance(string connection)
        {
            if (instance == null)
            {
                instance = new cosmeticDB(connection);

            }
            return instance;
        }


        public List<products> showallproducts()
        {


            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT  name,Type,  Company,  Color, Cost,Availibility,  DateOfManufacture,DateOfExpire, " +
                    " WarrantyDuration, Dimensions, Quantity ,skintype,shade,packagingtype FROM cosmetics", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string name = Convert.ToString(reader["name"]);
                    string Type = Convert.ToString(reader["Type"]);
                    string Company = Convert.ToString(reader["Company"]);
                    string[] Color = Convert.ToString(reader["Color"]).Split(',');
                    float Cost = Convert.ToSingle(reader["Cost"]);
                    int Availibility = Convert.ToInt32(reader["Availibility"]);
                    DateTime DateOfManufacture = Convert.ToDateTime(reader["DateOfManufacture"]);
                    DateTime DateOfExpire = Convert.ToDateTime(reader["DateOfExpire"]);
                    float WarrantyDuration = Convert.ToSingle(reader["WarrantyDuration"]);
                    string[] Dimensions = Convert.ToString(reader["Dimensions"]).Split(',');
                    float Quantity = Convert.ToSingle(reader["Quantity"]);
                    string skintype = Convert.ToString(reader["skintype"]);
                    string shade = Convert.ToString(reader["shade"]);
                    string packagingtype= Convert.ToString(reader["packagingtype"]);



                   cosmetics cosmeticitem = new cosmetics(name, Type, Company, Color, Cost, Availibility, DateOfManufacture, DateOfExpire, WarrantyDuration, Dimensions, Quantity, skintype, shade, packagingtype);


                    cosmeticslist.Add(cosmeticitem);
                }

                reader.Close();

            }
            return cosmeticslist;

        }
        public void SaveSelectedItems(List<ListViewItem> selectedItems, string username, int id)
        {
           

            try
            {
                using (SqlConnection connections = new SqlConnection(connection))
                {
                    connections.Open();
                    string insertQuery = "INSERT INTO boughtrecently (UserID, CustomerName, name, Cost, Company, Color, Type) VALUES (@id, @username, @name, @Cost, @Company, @Color, @Type)";

                    foreach (ListViewItem item in selectedItems)
                    {
                        using (SqlCommand command = new SqlCommand(insertQuery, connections))
                        {
                            command.Parameters.AddWithValue("@id", id);
                            command.Parameters.AddWithValue("@username", username);
                            command.Parameters.AddWithValue("@name", item.SubItems[0].Text);
                            command.Parameters.AddWithValue("@Cost", item.SubItems[1].Text);
                            command.Parameters.AddWithValue("@Company", item.SubItems[2].Text);
                            command.Parameters.AddWithValue("@Color", item.SubItems[3].Text);
                            command.Parameters.AddWithValue("@Type", item.SubItems[4].Text);

                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               
                MessageBox.Show("An error occurred while inserting data: " + ex.Message);
              
            }
        }

        public void storeindb(List<cosmetics> itemstostore)
        {
            try
            {
                using (SqlConnection connections = new SqlConnection(connection))
                {
                    connections.Open();
                    string insertQuery = "INSERT INTO cosmetics (name,Type,Company,Color,Cost,Availibility,DateOfManufacture,DateOfExpire,WarrantyDuration,Dimensions,Quantity" +
                        ",skintype,shade,packagingtype) VALUES (@name,@Type,@Company,@Color,@Cost,@Availibility,@DateOfManufacture,@DateOfExpire,@WarrantyDuration,@Dimensions,@Quantity" +
                        ",@skintype,@shade,@packagingtype)";

                    foreach (cosmetics item in itemstostore)
                    {
                        using (SqlCommand command = new SqlCommand(insertQuery, connections))
                        {
                          // Assuming cosmeticid is a property of the products class
                            command.Parameters.AddWithValue("@name", item.getname());
                            command.Parameters.AddWithValue("@Type", item.getType());
                            command.Parameters.AddWithValue("@Company", item.getcompany());
                            command.Parameters.AddWithValue("@Color", item.getcolor());
                            command.Parameters.AddWithValue("@Cost", item.getcost());
                            command.Parameters.AddWithValue("@Availibility", item.getavailibility());
                            command.Parameters.AddWithValue("@DateOfManufacture", item.getdateofmanufacture());
                            command.Parameters.AddWithValue("@DateOfExpire", item.getdateofexpire());
                            command.Parameters.AddWithValue("@WarrantyDuration", item.getwarrantyDuration());
                            command.Parameters.AddWithValue("@Dimensions", item.getdimensions());
                            command.Parameters.AddWithValue("@Quantity", item.getquantity());
                            command.Parameters.AddWithValue("@skintype", item.getskintype());
                            command.Parameters.AddWithValue("@shade", item.getshade());
                            command.Parameters.AddWithValue("@packagingtype", item.getPackagingtype());



                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred while inserting data: " + ex.Message);

            }
        }
        public void updateindb(List<cosmetics> itemstostore, int id)
        {
            try
            {
                using (SqlConnection connections = new SqlConnection(connection))
                {
                    connections.Open();
                    string updateQuery = "UPDATE cosmetics SET name = @name, Company = @Company, Color = @Color," +
                        " Cost = @Cost, DateOfManufacture = @DateOfManufacture, DateOfExpire = @DateOfExpire," +
                        " WarrantyDuration = @WarrantyDuration, Dimensions = @Dimensions, Quantity = @Quantity," +
                        " skintype = @skintype, shade = @shade, packagingtype = " +
                        "@packagingtype WHERE cosmeticID = @id";


                    foreach (cosmetics item in itemstostore)
                    {
                        using (SqlCommand command = new SqlCommand(updateQuery, connections))
                        {
                            // Assuming cosmeticid is a property of the products class
                            command.Parameters.AddWithValue("@id", id);
                            command.Parameters.AddWithValue("@name", item.getname());

                            command.Parameters.AddWithValue("@Company", item.getcompany());
                            command.Parameters.AddWithValue("@Color", item.getcolor());
                            command.Parameters.AddWithValue("@Cost", item.getcost());

                            command.Parameters.AddWithValue("@DateOfManufacture", item.getdateofmanufacture());
                            command.Parameters.AddWithValue("@DateOfExpire", item.getdateofexpire());
                            command.Parameters.AddWithValue("@WarrantyDuration", item.getwarrantyDuration());
                            command.Parameters.AddWithValue("@Dimensions", item.getdimensions());
                            command.Parameters.AddWithValue("@Quantity", item.getquantity());
                            command.Parameters.AddWithValue("@skintype", item.getskintype());
                            command.Parameters.AddWithValue("@shade", item.getshade());
                            command.Parameters.AddWithValue("@packagingtype", item.getPackagingtype());



                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred while inserting data: " + ex.Message);

            }
        }
        public int retrieveid(string name, string company)
        {
            int id = -1;



            string query = "SELECT cosmeticID FROM cosmetics WHERE name = @name and Company = @company";

            using (SqlConnection connections = new SqlConnection(connection))
            {
                using (SqlCommand command = new SqlCommand(query, connections))
                {

                    command.Parameters.AddWithValue("@name", name.Trim());
                    command.Parameters.AddWithValue("@company", company.Trim());
                    connections.Open();

                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        id = Convert.ToInt32(result);
                    }

                }
            }


            return id;
        }
        public void removefromdb(int id)
        {
            try
            {
                using (SqlConnection connections = new SqlConnection(connection))
                {
                    connections.Open();
                    string deleteQuery = "DELETE FROM cosmetics WHERE cosmeticID = @id";
                    using (SqlCommand command = new SqlCommand(deleteQuery, connections))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while deleting data: " + ex.Message);
            }
        }
    }



}

