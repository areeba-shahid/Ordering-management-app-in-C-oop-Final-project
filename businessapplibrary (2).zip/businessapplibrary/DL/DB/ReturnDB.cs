﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace businessapplibrary
{
    public class ReturnDB : IreturnDL
    {
        string connection = "";
        static List<ReturnItem> items;
        static ReturnDB instance;
        public ReturnDB(string connection)
        {
            this.connection = connection;

        }
        public static ReturnDB getInstance(string connection)
        {
            if (instance == null)
            {
                instance = new ReturnDB(connection);
                items = new List<ReturnItem>();
            }
            return instance;
        }
        public List<ReturnItem> retrievedata(string username, int userid)
        {
            string query = "SELECT itemid, name, colorselected,Color, Cost ,Company ,Type FROM bought WHERE CustomerName = @username AND UserID = @userid";

           


            using (SqlConnection connections = new SqlConnection(connection))
            {
              
                connections.Open();

                using (SqlCommand command = new SqlCommand(query, connections))
                {
                    
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@userid", userid);

                   
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                           

                            ReturnItem item = new ReturnItem();
                           
                            item.ItemId = reader.GetInt32(0);
                            item.setname(reader.GetString(1));

                         
                            float cost;
                            if (float.TryParse(reader.GetString(4), out cost))
                            {
                                item.setcost(cost);
                            }
                            else
                            {
                                MessageBox.Show("Error parsing cost");
                            }

                            
                            string color = reader.IsDBNull(2) ? null : reader.GetString(2);

                            
                            if (string.IsNullOrEmpty(color))
                            {
                               
                                color = reader.IsDBNull(3) ? null : reader.GetString(3);
                            }

                           
                            item.Color = color;

                            item.setcompany(reader.GetString(5)); 
                            item.settype(reader.GetString(6)); 

                           
                            items.Add(item);


                        }
                    }
                }
            }
            return items;
        }
        public void WriteReturnedItems(List<ReturnItem> items, int userid, string name)
        {
            string query = "INSERT INTO returneditems (itemid,UserID,CustomerName, name, Color, Cost, Company, Type) VALUES (@itemid,@UserID,@CustomerName, @name, @color, @cost, @company, @type)";

            using (SqlConnection connections = new SqlConnection(connection))
            {
               
                connections.Open();

                foreach (var item in items)
                {
                    using (SqlCommand command = new SqlCommand(query, connections))
                    {
                       
                        command.Parameters.AddWithValue("@UserID", userid);
                        command.Parameters.AddWithValue("@CustomerName", name);
                        command.Parameters.AddWithValue("@itemid", item.ItemId);
                        command.Parameters.AddWithValue("@name", item.getname());
                        command.Parameters.AddWithValue("@color", item.Color);
                        command.Parameters.AddWithValue("@cost", item.getcost());
                        command.Parameters.AddWithValue("@company", item.getcompany());
                        command.Parameters.AddWithValue("@type", item.getType());

                      
                        command.ExecuteNonQuery();
                    }
                }
            }
        }
        public void RemoveProductFromBoughtItems(int itemId, string customerName)
        {
           
            string sqlDelete = "DELETE FROM bought WHERE ItemId = @ItemId AND CustomerName = @CustomerName";

            
            using (SqlConnection connections = new SqlConnection(connection))
            {
                try
                {
                    
                    connections.Open();

                  
                    using (SqlCommand command = new SqlCommand(sqlDelete, connections))
                    {
                        // Add parameters to the command
                        command.Parameters.AddWithValue("@ItemId", itemId);
                        command.Parameters.AddWithValue("@CustomerName", customerName);

                      
                        command.ExecuteNonQuery();
                    }

                    Console.WriteLine("Product removed from boughtitems table.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An error occurred: " + ex.Message);
                }
            }
        }
        public List<ReturnItem> PopulateListViewWithReturnedProducts(int id, string username)
        {


            string query = "SELECT itemid, name,Color, Cost ,Company ,Type FROM returneditems WHERE CustomerName = @username AND UserID = @userid";

          


            using (SqlConnection connections = new SqlConnection(connection))
            {
               
                connections.Open();

                using (SqlCommand command = new SqlCommand(query, connections))
                {
                  
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@userid", id);

                   
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                           

                            ReturnItem item = new ReturnItem();
                         
                            item.ItemId = reader.GetInt32(0);
                            item.setname(reader.GetString(1));
                            item.Color = (reader.GetString(2));
                           
                            if (!reader.IsDBNull(3)) 
                            {
                              
                                double costValue = reader.GetDouble(3);

                                
                                item.setcost((float)costValue);
                            }
                            else
                            {
                                MessageBox.Show("Error: Cost value is null.");
                            }

                        


                            item.setcompany(reader.GetString(4)); 
                            item.settype(reader.GetString(5));
                          
                            items.Add(item);


                        }
                    }
                }
            }
            return items;

        }


        public List<ReturnItem> retrieveall()
        {
            try
            {
                using (SqlConnection connections = new SqlConnection(connection))
                {
                   
                    connections.Open();

                  
                    string query = "SELECT * FROM returnedItems";

                  
                    using (SqlCommand command = new SqlCommand(query, connections))
                    {
                      
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                          
                            if (reader.HasRows)
                            {
                                
                                while (reader.Read())
                                {
                                   
                                    int itemid = Convert.ToInt32(reader["itemid"]);
                                  int customerid = Convert.ToInt32(reader["UserID"]);
                                   string Customername = Convert.ToString(reader["CustomerName"]);

                                    string name = Convert.ToString(reader["name"]);
                                    string color = Convert.ToString(reader["Color"]);
                                    string company = Convert.ToString(reader["Company"]);

                                    float Price = Convert.ToSingle(reader["Cost"]);
                                    string type = Convert.ToString(reader["type"]);
                                    ReturnItem pay = new ReturnItem(itemid, customerid, Customername, name, color,Price, company,type);

                                    items.Add(pay);



                                }
                            }
                            else
                            {
                                MessageBox.Show("No rows found in the result set");
                               
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return items;
        
    }

    }
}

