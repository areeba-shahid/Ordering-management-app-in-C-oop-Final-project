﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businessapplibrary
{
    public class paymentDB : IpaymentDL
    {
        string connection = "";

        static paymentDB instance;

        List<paymentBL> paymentrecords { get; set; }

        public paymentDB(string connection)
        {
            this.connection = connection;
            paymentrecords = new List<paymentBL>();
        }
        public static paymentDB getInstance(string connection)
        {
            if (instance == null)
            {
                instance = new paymentDB(connection);

            }
            return instance;
        }
        public void storepaymentrecord(string CustomerName, int CustomerId, float Price, string PaymentMethod, string itemsbought)
        {

            using (SqlConnection connections = new SqlConnection(connection))
            {

                string query = @"INSERT INTO ToShip ( CustomerName, CustomerID,itemsbought,bill, paymentMethod)
                         VALUES ( @CustomerName, @CustomerId,@itemsbought, @Price, @PaymentMethod)";


                using (SqlCommand command = new SqlCommand(query, connections))
                {
                    // Add parameters to the query to prevent SQL injection

                    command.Parameters.AddWithValue("@CustomerName", CustomerName);
                    command.Parameters.AddWithValue("@CustomerId", CustomerId);
                    command.Parameters.AddWithValue("@itemsbought", itemsbought);
                    command.Parameters.AddWithValue("@Price", Price);
                    command.Parameters.AddWithValue("@PaymentMethod", PaymentMethod);

                    try
                    {

                        connections.Open();


                        command.ExecuteNonQuery();
                        GetAllDataFromToShip();
                    }

                    catch (SqlException ex)
                    {
                       
                        MessageBox.Show("Error storing payment record: " + ex.Message);
                    }
                }
            }
        }

        public List<paymentBL> GetAllDataFromToShip()
        {


            string query = "SELECT * FROM ToShip";

            using (SqlConnection connections = new SqlConnection(connection))
            {
                SqlCommand command = new SqlCommand(query, connections);


                connections.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {

                    int OrderId = Convert.ToInt32(reader["OrderId"]);
                    string CustomerName = Convert.ToString(reader["CustomerName"]);
                    int CustomerId = Convert.ToInt32(reader["CustomerId"]);

                    string Items = Convert.ToString(reader["itemsbought"]);
                    List<string> ItemsList = Items.Split(',').ToList();
                    float Price = Convert.ToSingle(reader["bill"]);
                    string PaymentMethod = Convert.ToString(reader["PaymentMethod"]);
                    paymentBL pay = new paymentBL(OrderId, CustomerName, CustomerId, ItemsList, Price, PaymentMethod);

                    paymentrecords.Add(pay);
                }

                reader.Close();

            }

            return paymentrecords;
        }
        public void UpdateUsernameAndPassword(string previousUsername, int id, string newUsername)
        {
            // SQL query to update the username and password where previous credentials match
            string query = "UPDATE ToShip SET CustomerName = @newUsername WHERE CustomerName = @previousUsername AND CustomerID = @id";

            // Establish a connection to the database
            using (SqlConnection connections = new SqlConnection(connection))
            {
                // Open the connection
                connections.Open();

                using (SqlCommand command = new SqlCommand(query, connections))
                {
                   
                    command.Parameters.AddWithValue("@previousUsername", previousUsername);

                    command.Parameters.AddWithValue("@newUsername", newUsername);
                    command.Parameters.AddWithValue("@id", id);

               
                    int rowsAffected = command.ExecuteNonQuery();

                   
                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Username and password updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("No rows were updated. Previous credentials may not match.");
                    }
                }
            }
        }
        public List<paymentBL> getalltoshipitem()
        {
            try
            {
              
                using (SqlConnection connections = new SqlConnection(connection))
                {
                   
                    connections.Open();

                   
                    string query = "SELECT * FROM ToShip";

               
                    using (SqlCommand command = new SqlCommand(query, connections))
                    {
                      
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                          
                            if (reader.HasRows)
                            {
                               
                                while (reader.Read())
                                {
                                  
                                    int OrderId = Convert.ToInt32(reader["OrderId"]);
                                    string CustomerName = Convert.ToString(reader["CustomerName"]);
                                    int CustomerId = Convert.ToInt32(reader["CustomerId"]);

                                    string Items = Convert.ToString(reader["itemsbought"]);
                                    List<string> ItemsList = Items.Split(',').ToList();
                                    float Price = Convert.ToSingle(reader["bill"]);
                                    string PaymentMethod = Convert.ToString(reader["PaymentMethod"]);
                                    paymentBL pay = new paymentBL(OrderId, CustomerName, CustomerId, ItemsList, Price, PaymentMethod);

                                    paymentrecords.Add(pay);



                                }
                            }
                            else
                            {
                                MessageBox.Show("No rows found in the result set");
                                
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               
               MessageBox.Show("An error occurred: " + ex.Message);
            }
            return paymentrecords;
        }

    }
}

