﻿

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businessapplibrary
{
    public class signupDB : IsignupDL
    {
        string connection = "";

        static signupDB instance;

        public signupDB(string connection)
        {
            this.connection = connection;
            
        }
        public static signupDB getInstance(string connection)
        {
            if (instance == null)
            {
                instance = new signupDB(connection);

            }
            return instance;
        }

        private static List<signupBL> userslist = new List<signupBL>();

        public void adduserintolist(signupBL user)
        {
            userslist.Add(user);
           
        }


        public  List<signupBL> GetUsers()
        {


            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT UserName, UserPassword, Roll FROM signup", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    signupBL user = new signupBL(reader["UserName"].ToString(), reader["UserPassword"].ToString(), reader["Roll"].ToString());


                    adduserintolist(user);
                }

                reader.Close();

            }
            return userslist;
        }


        public  signupBL signin(signupBL user)
        {
            foreach (signupBL storeduser in userslist)
            {
                if (storeduser.getname() == user.getname() && storeduser.getpass() == user.getpass())
                {
                    return storeduser;
                }
            }
            return null;
        }
       public bool validityofpassword(string password)
        {
            if (string.IsNullOrEmpty(password) || password.Length < 8)
            {
                return false;
            }

           
            else if (!char.IsUpper(password[0]))
            {
                return false;
            }
            else
            {
                return true;
            }

        }
        public string GetRoll(string UserName, string UserPassword)
        {
            string roll = null;
            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();
                string query = "SELECT Roll FROM signup WHERE UserName = @UserName AND UserPassword = @UserPassword";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserName", UserName);
                    cmd.Parameters.AddWithValue("@UserPassword", UserPassword);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            roll = reader["Roll"].ToString();
                        }
                    }
                }
            }
            return roll;
        }
        public  bool IsPasswordUnique(string password)
        {
            bool isUnique = true;

            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM signup WHERE UserPassword = @UserPassword";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserPassword", password);

                    int count = (int)cmd.ExecuteScalar(); 

                    if (count > 0)
                    {
                        isUnique = false; 
                    }
                }
            }

            return isUnique;
        }
        public bool IsusernameUnique(string UserName)
        {
            bool isUnique = true;

            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM signup WHERE UserName = @UserName";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserName", UserName);

                    int count = (int)cmd.ExecuteScalar(); 

                    if (count > 0)
                    {
                        isUnique = false; 
                    }
                }
            }

            return isUnique;
        }

        public signupBL storerespectively(string name,string pass,string roll)
        {
            SqlConnection conn = new SqlConnection(connection);
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into signup values(@username, @userpassword, @roll)", conn);



            cmd.Parameters.AddWithValue("@username", name);
            cmd.Parameters.AddWithValue("@userpassword", pass);
            cmd.Parameters.AddWithValue("@roll", roll);
            signupBL user = new signupBL(name,pass,roll);
            adduserintolist(user);


            cmd.ExecuteNonQuery();
            conn.Close();
            return user;
        }

        public int GetUserID(string UserName)
        {
            int UserID = -1;

           
            if (!string.IsNullOrEmpty(UserName))
            {
                string query = "SELECT UserID FROM signup WHERE UserName = @UserName";

                using (SqlConnection connections = new SqlConnection(connection))
                {
                    using (SqlCommand command = new SqlCommand(query, connections))
                    {
                      
                        command.Parameters.AddWithValue("@UserName", UserName.Trim());
                        connections.Open();

                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            UserID = Convert.ToInt32(result);
                        }

                    }
                }
            }

            return UserID;
        }

        public string RetrievePassword(string username, int id)
        {
            string password = null; // Initialize password variable

           
            string query = "SELECT UserPassword FROM signup WHERE Username = @username AND UserID = @id";

           
            using (SqlConnection connections = new SqlConnection(connection))
            {
               
                connections.Open();

               
                using (SqlCommand command = new SqlCommand(query, connections))
                {
                   
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@id", id);

                    
                    object result = command.ExecuteScalar();

                    
                    if (result != null)
                    {
                       
                        password = result.ToString();
                    }
                }
            }

          
            return password;
        }
        public string RetrievePassword( int id)
        {
            string password = null; // Initialize password variable


            string query = "SELECT UserPassword FROM signup WHERE  UserID = @id";


            using (SqlConnection connections = new SqlConnection(connection))
            {

                connections.Open();


                using (SqlCommand command = new SqlCommand(query, connections))
                {


                    command.Parameters.AddWithValue("@id", id);


                    object result = command.ExecuteScalar();


                    if (result != null)
                    {

                        password = result.ToString();
                    }
                }
            }


            return password;
        }
        public void UpdateUsernameAndPassword(string previousUsername, string previousPassword, string newUsername, string newPassword)
        {
           
            string query = "UPDATE signup SET Username = @newUsername, UserPassword = @newPassword WHERE Username = @previousUsername AND UserPassword = @previousPassword";

           
            using (SqlConnection connections = new SqlConnection(connection))
            {
              
                connections.Open();

               
                using (SqlCommand command = new SqlCommand(query, connections))
                {
                   
                    command.Parameters.AddWithValue("@previousUsername", previousUsername);
                    command.Parameters.AddWithValue("@previousPassword", previousPassword);
                    command.Parameters.AddWithValue("@newUsername", newUsername);
                    command.Parameters.AddWithValue("@newPassword", newPassword);

                   
                    int rowsAffected = command.ExecuteNonQuery();

                   
                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Username and password updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("No rows were updated. Previous credentials may not match.");
                    }
                }
            }
        }
        public List<signupBL> getall()
        {
            userslist.Clear();
            try
            {
               
                using (SqlConnection connections = new SqlConnection(connection))
                {
                 
                    connections.Open();

                    
                    string query = "SELECT * FROM signup";

                    
                    using (SqlCommand command = new SqlCommand(query, connections))
                    {
                        
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                           
                            if (reader.HasRows)
                            {
                               
                                while (reader.Read())
                                {
                                   
                                    int userId = Convert.ToInt32(reader["UserID"]);
                                    string CustomerName = Convert.ToString(reader["UserName"]);
                                string password = Convert.ToString(reader["UserPassword"]);

                                    string roll = Convert.ToString(reader["Roll"]);
                                   
                                    signupBL pay = new signupBL(userId,CustomerName,password,roll);

                                    userslist.Add(pay);



                                }
                            }
                            else
                            {
                                MessageBox.Show("No rows found in the result set");
                               
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
              
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return userslist;
        }
        public void DeleteUserById(int id)
        {
            try
            {
                using (SqlConnection connections = new SqlConnection(connection))
                {
                    connections.Open();

                    string query = "DELETE FROM signup WHERE UserID = @id";

                    using (SqlCommand command = new SqlCommand(query, connections))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
               
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
    }
}

