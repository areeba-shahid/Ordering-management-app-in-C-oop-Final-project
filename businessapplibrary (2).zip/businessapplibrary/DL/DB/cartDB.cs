﻿

using System;
using System.Data;

using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace businessapplibrary
{
    public class cartDB : IcartDL
    {
        string connection = "";

        static cartDB instance;
        public List<CartItem> Items { get; private set; }


        public cartDB(string connection)
        {
            this.connection = connection;
            Items = new List<CartItem>();
        }
        public static cartDB getInstance(string connection)
        {
            if (instance == null)
            {
                instance = new cartDB(connection);

            }
            return instance;
        }
        public List<CartItem> PopulateCart(string CustomerName, int UserID)
        {
            List<CartItem> items = new List<CartItem>();
            try
            {
                
                string query = "SELECT itemid ,name, Cost, Color FROM boughtrecently WHERE CustomerName = @CustomerName AND UserID = @UserID";

              
                using (SqlConnection connections = new SqlConnection(connection))
                {
                    SqlCommand command = new SqlCommand(query, connections);

                  
                    command.Parameters.AddWithValue("@CustomerName", CustomerName);
                    command.Parameters.AddWithValue("@UserID", UserID);

                    connections.Open();

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        int itemid = Convert.ToInt32(reader["itemid"]);
                        string itemName = reader["name"].ToString();
                        string costString = reader["Cost"].ToString();
                        string colorOptionsString = reader["Color"].ToString();




                      
                        float itemPrice = float.Parse(costString);

                      
                        List<string> colorOptions = colorOptionsString.Split(',').ToList();

                       
                        bool hasColorOptions = colorOptions.Count > 1;

                      
                        CartItem item = new CartItem(itemid, itemName, itemPrice, hasColorOptions, colorOptions);
                        items.Add(item);
                    }

                    reader.Close();
                }
            }
            catch (SqlException ex)
            {
               
                Console.WriteLine("An SQL exception occurred: " + ex.Message);
            }

            return items;
        }
        public void UpdateColor(int itemId, string selectedColor)
        {
            using (SqlConnection connections = new SqlConnection(connection))
            {
                string query;
                SqlCommand command;




              
                query = "UPDATE boughtrecently SET colorselected = @SelectedColor WHERE itemid = @ItemId";
                command = new SqlCommand(query, connections);
                command.Parameters.AddWithValue("@SelectedColor", selectedColor);


                command.Parameters.AddWithValue("@ItemId", itemId);

                try
                {
                    connections.Open();
                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Error updating color in database: " + ex.Message);
                }
            }
        }

     




    public void DeleteItemFromStorage(int itemId)
        {
            // Define the SQL query to delete the item with the given itemId
            string query = "DELETE FROM boughtrecently WHERE ItemID = @itemId";

            // Create a new SqlConnection using the connection string
            using (SqlConnection connections = new SqlConnection(connection))
            {
                // Create a SqlCommand object with the query and connection
                using (SqlCommand command = new SqlCommand(query, connections))
                {
                    // Add parameters to the query to prevent SQL injection
                    command.Parameters.AddWithValue("@itemId", itemId);

                    try
                    {
                        // Open the connection
                        connections.Open();

                        // Execute the SQL command to delete the item
                        command.ExecuteNonQuery();


                    }
                    catch (SqlException ex)
                    {
                        // Handle any exceptions
                        Console.WriteLine("Error deleting item from storage: " + ex.Message);
                    }
                }
            }
        }





        public DataTable RetrieveDataFromBoughtRecently()
        {
            string selectQuery = @"
        SELECT * 
        FROM boughtrecently
    ";

            DataTable dataTable = new DataTable();

            using (SqlConnection connections = new SqlConnection(connection))
            {
                connections.Open();

                using (SqlCommand selectCommand = new SqlCommand(selectQuery, connections))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(selectCommand))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }

        public void InsertDataIntoBought(DataTable dataTable)
        {
            string insertQuery = @"
        INSERT INTO bought (ItemId, UserID, CustomerName, name, Cost, Company, Color, Type, colorselected)
        VALUES (@ItemId, @UserID, @CustomerName, @name, @Cost, @Company, @Color, @Type, @colorselected)
    ";

            using (SqlConnection connections = new SqlConnection(connection))
            {
                connections.Open();

                foreach (DataRow row in dataTable.Rows)
                {
                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connections))
                    {
                        insertCommand.Parameters.AddWithValue("@ItemId", row["ItemId"]);
                        insertCommand.Parameters.AddWithValue("@UserID", row["UserID"]);
                        insertCommand.Parameters.AddWithValue("@CustomerName", row["CustomerName"]);
                        insertCommand.Parameters.AddWithValue("@name", row["name"]);
                        insertCommand.Parameters.AddWithValue("@Cost", row["Cost"]);
                        insertCommand.Parameters.AddWithValue("@Company", row["Company"]);
                        insertCommand.Parameters.AddWithValue("@Color", row["Color"]);
                        insertCommand.Parameters.AddWithValue("@Type", row["Type"]);
                        insertCommand.Parameters.AddWithValue("@colorselected", row["colorselected"]);

                        insertCommand.ExecuteNonQuery();
                    }
                }
            }
        }


        public void DeleteAllDataFromBoughtRecently()
        {
           // Replace with your actual connection string

            string deleteQuery = @"
        DELETE FROM boughtrecently
    ";

            using (SqlConnection connections = new SqlConnection(connection))
            {
                connections.Open();

                // Execute the delete query
                using (SqlCommand command = new SqlCommand(deleteQuery, connections))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public void UpdateUsernameAndPassword(string previousUsername, int id, string newUsername)
        {
            // SQL query to update the username and password where previous credentials match
            string query = "UPDATE bought SET CustomerName = @newUsername WHERE CustomerName = @previousUsername AND UserID = @id";

            // Establish a connection to the database
            using (SqlConnection connections = new SqlConnection(connection))
            {
                // Open the connection
                connections.Open();

                // Create a SqlCommand object to execute the query
                using (SqlCommand command = new SqlCommand(query, connections))
                {
                    // Add parameters to the command for previous and new credentials
                    command.Parameters.AddWithValue("@previousUsername", previousUsername);
                    
                    command.Parameters.AddWithValue("@newUsername", newUsername);
                    command.Parameters.AddWithValue("@id", id);

                    // Execute the UPDATE query
                    int rowsAffected = command.ExecuteNonQuery();

                    // Check if any rows were affected by the update
                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Username and password updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("No rows were updated. Previous credentials may not match.");
                    }
                }
            }
        }
       

    }
}


